


mkdir -p /data/Mariadb/{dev,test}
mkdir -p /data/logs/Mariadb/{dev,test}
chown -R 999:999 /data/logs/Mariadb/
chown 999:999 /data/Mariadb/*.cnf






###備份所有資料庫
docker exec -it dev-mariadb-10.8.8 mysqldump -u root -pAbcdE230982 --single-transaction --routines --triggers --all-databases > dev_all_backup.sql

#####還原全部資料庫
cat 20240125_04-00-01.sql | docker exec -i dev-mariadb-10.8.8 mysql -u root -pAbcdE230982
cat 20240125_04-00-01.sql | docker exec -i test-mariadb-10.8.8 mysql -u root -pAbcdE230982


#####
Debian系统安装mysqldump的方法：

更新系统软件包列表：sudo apt-get update
安装mysqldump：sudo apt-get install mariadb-client
检查安装是否成功：mysqldump --version







