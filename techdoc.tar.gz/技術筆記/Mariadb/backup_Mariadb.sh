#!/bin/bash
LOG_FILE="/data/scripts/backup_mariadb.log"
TELEGRAM_API="https://api.telegram.org/bot6840034038:AAGY75FhkkEZXpXz309S5OM5_rkVcSvgYvI/sendMessage"
CHAT_ID="-4124097058"

host="127.0.0.1"
db_user="root"
db_pwd="AbcdE230982"
database="goplay_games"

function send_telegram_notification() {
    local time=$(date "+%Y-%m-%d %H:%M:%S")
    local svc_kind="$1"
    local svc_name="$2"
    local svc_status="$3"

    curl -s -X POST \
        -H 'Content-Type: application/json' \
        -d '{"chat_id": "'"$CHAT_ID"'", "text":" '"执行时间: ${time} UTC \n环境名称: $svc_kind \n服务名称: $svc_name \n状态异常: $svc_status \n详细日志:见如下日志文件. "'", "disable_notification": true}' \
        "$TELEGRAM_API" 1>/dev/null
}

function backup_database() {
    local backup_type="$1"
    local db_port="$2"
    local backup_dir="$3"
    local now=$(date "+%Y%m%d_%H-%M-%S")
    local file="$backup_dir/$now/$now.sql.gz"

    [ ! -d "$backup_dir/$now" ] && mkdir -p "$backup_dir/$now"

    echo "执行[mysqldump -u$db_user -p$db_pwd -P$db_port --host=$host -q -R --database $database  | gzip > $file]"

    if ! { mysqldump -u"$db_user" -p"$db_pwd" -P"$db_port" --host="$host" -q -R --database "$database" | gzip > "$file"; }; then
        echo "***备份失败！在查看到此提示信息后请及时检查并处理！"
        send_telegram_notification "$backup_type" "$database" "🔥备份失败"
    else
        if [ -f "$file" -a -s "$file" ]; then
            echo "***备份成功"
            send_telegram_notification "$backup_type" "$database" "备份成功"
        else
            echo "***备份失败！在查看到此提示信息后请及时检查并处理！"
            send_telegram_notification "$backup_type" "$database" "🔥备份失败"
        fi
    fi
}

function cleanup_old_backups() {
    local backup_type="$1"
    local backup_dir="$2"
    local log_date=$(date "+%Y%m%d_%H-%M-%S")
    local log_file="/data/scripts/backup_cleanup_$backup_type.log"
    local backup_dir="/data/backup/mariadb-$backup_type"
    echo "$log_date" >> "$log_file"

    find "$backup_dir" -type d -ctime +30 -exec sh -c 'echo "{}" >> "$log_file"; rm -rf "{}"' \;

    echo "执行 cleanup_old_backups，删除的备份信息已记录在日志文件 $log_file"
}

# Backup for dev
backup_database "dev" "3307" "/data/backup/mariadb-dev"
cleanup_old_backups "dev" "/data/backup/mariadb-dev"

# Backup for test
backup_database "test" "3306" "/data/backup/mariadb-test"
cleanup_old_backups "test" "/data/backup/mariadb-test"
