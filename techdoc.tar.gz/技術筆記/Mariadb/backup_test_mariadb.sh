#!/bin/bash
NOW=$(date "+%Y%m%d_%H-%M-%S")
BACKUP=/data/backup/mariadb-test


HOST=127.0.0.1
DB_USER=root
DB_PWD=AbcdE230982
DATABASE=goplay_games
DB_PORT=3306

[ ! -d $BACKUP/$NOW ] && mkdir -p $BACKUP/$NOW
FILE=$BACKUP/$NOW/$NOW.sql.gz

mysqldump -u$DB_USER -p$DB_PWD -P$DB_PORT --host=$HOST -q -R --database $DATABASE  | gzip > $FILE

echo "执行[mysqldump -u$DB_USER -p$DB_PWD -P$DB_PORT --host=$HOST -q -R --database $DATABASE  | gzip > $FILE]"

if [ -f $FILE -a -s $FILE ]
then
        echo "***备份成功"
else
        echo "***备份失败！在查看到此提示信息后请及时检查并处理！"
fi
FILE=$NOW.tar.gz
cd $BACKUP

echo "*- 正在将备份资源打包为$FILE"
tar -zvcf $BACKUP/$FILE $NOW
rm -rf $NOW
NOW=$(date "+%y-%m-%d_%H:%M:%S")
echo "*- 数据库$DATABASE 备份已完成"
echo "*- 当前时间：$NOW -*"