#!/bin/bash

# 檢查 Docker 是否已安裝
if ! command -v docker &> /dev/null; then
    echo "Docker is not installed. Please install Docker and run the script again."
    exit 1
fi

# 檢查 Docker 容器是否已存在
check_container_exists() {
    local container_name="$1"
    if docker ps -a --format '{{.Names}}' | grep -q "$container_name"; then
        echo "Container '$container_name' already exists. Exiting script."
        echo "容器 '$container_name' 已經存在，不允許安裝，離開腳本."
        exit 0
    fi
}

# 檢查 Kibana 容器是否已存在
check_container_exists "kibana"

# 檢查 Logstash 容器是否已存在
check_container_exists "logstash"

# 檢查 Elasticsearch 容器是否已存在
check_container_exists "elasticsearch"

# 創建 ELK 目錄
ELK_DIR="/data/elk"
if [ ! -d "$ELK_DIR" ]; then
    mkdir -p "$ELK_DIR"/{es_data/{config,data,plugins},kibana,logstash}
    chmod -R 777 "$ELK_DIR"/es_data/data
fi

# 取得本機 IP 地址
CURRENT_IP=$(ip addr show dev ens5 | awk '/inet / {print $2}' | cut -d'/' -f1)
echo "Current IP address is: $CURRENT_IP"
echo "目前ip請確認是否正確: $CURRENT_IP"

# 提示用戶確認是否繼續執行
read -p "Do you want to continue? (yes/no): " answer
if [ "$answer" != "yes" ]; then
    echo "Exiting script."
    exit 0
fi

# 配置 Elasticsearch YAML 檔案
ES_YAML_FILE="$ELK_DIR/es_data/config/elasticsearch.yml"
if [ ! -f "$ES_YAML_FILE" ]; then
    cat > "$ES_YAML_FILE" << EOF
http.host: 0.0.0.0
http.cors.enabled: true
http.cors.allow-origin: "*"
http.cors.allow-headers: Authorization
cluster.max_shards_per_node: 5000

# Elasticsearch 相關配置
indices.memory.index_buffer_size: 20%
indices.memory.min_index_buffer_size: 48mb
indices.memory.max_index_buffer_size: 256mb
indices.fielddata.cache.size: 15%
indices.query.bool.max_clause_count: 2048
thread_pool.search.queue_size: 5000
thread_pool.write.queue_size: 5000
#indices.store.throttle.max_bytes_per_sec: 75mb
#index.refresh_interval: 30s

# 調整緩存
indices.breaker.fielddata.limit: 40%
indices.breaker.fielddata.overhead: 1.02
indices.breaker.request.limit: 40%
#indices.breaker.parent.limit: 50%

# 高並發設定
http.max_content_length: 300mb
indices.requests.cache.size: 5%
#indices.requests.cache.cleanup_interval: 5m

# 關閉 swap
bootstrap.memory_lock: true

# 適應性自動調整
cluster.routing.allocation.node_concurrent_recoveries: 1
cluster.routing.allocation.disk.threshold_enabled: false

# 關閉不需要的模組
xpack.ml.enabled: false
xpack.monitoring.enabled: false
xpack.security.enabled: false
xpack.watcher.enabled: false
EOF
fi


# 配置並啟動 Elasticsearch 容器
# 生產環境 -Xms8192m -Xmx8192m -XX:MaxDirectMemorySize=8192m -XX:NewRatio=1
# 測試或開發環境 -Xms1024m -Xmx1024m -XX:MaxDirectMemorySize=1024m -XX:NewRatio=1
# 測試或開發環境 使用1g 或2g 內存理論上是夠的。
docker run -d \
  --name elasticsearch  \
  --restart=always \
  -e "discovery.type=single-node"   \
  -e ES_JAVA_OPTS="-Xms8192m -Xmx8192m -XX:MaxDirectMemorySize=8192m -XX:NewRatio=1"  \
  -v "$ELK_DIR/es_data/config/elasticsearch.yml:/usr/share/elasticsearch/config/elasticsearch.yml" \
  -v "$ELK_DIR/es_data/data:/usr/share/elasticsearch/data"  \
  -v "$ELK_DIR/es_data/plugins:/usr/share/elasticsearch/plugins" \
  -p 9200:9200  \
  -p 9300:9300 \
  elasticsearch:7.17.16


# 配置 Logstash 資料夾
LOGSTASH_DIR="/data/elk/logstash"
if [ ! -d "$LOGSTASH_DIR" ]; then
    mkdir -p "$LOGSTASH_DIR"
fi

# 下載 GeoLite2-City.mmdb 檔案
GEOIP_DB_FILE="$LOGSTASH_DIR/GeoLite2-City.mmdb"
if [ ! -f "$GEOIP_DB_FILE" ]; then
    cd "$LOGSTASH_DIR"
    wget https://git.io/GeoLite2-City.mmdb
fi


# 配置 Logstash conf 檔案
LOG_CONF_FILE="$LOGSTASH_DIR/logstash.conf"
if [ ! -f "$LOG_CONF_FILE" ]; then
    cat > "$LOG_CONF_FILE" << EOF
input {
  tcp {
    type => "app"
    host => "0.0.0.0"
    port => 5506
    mode => "server"
    codec => json_lines
  }
  beats {
    host => "0.0.0.0"
    type => "nginx"
    port => 5046
    codec => json
  }
}
filter {
  if [type] == "nginx" {
          if "," in [xff] {
        mutate {
          split => ["xff", ","]
          add_field => { "real_remote_addr" => "%{[xff][0]}" }
        }
     } else if ([xff] == "-") {
        mutate {
          add_field => { "real_remote_addr" => "-" }
        }
     } else {
        mutate {
          add_field => { "real_remote_addr" => "%{xff}" }
        }
     }

     geoip {
       target => "geoip"
       source => "real_remote_addr"
       database => "/usr/share/logstash/GeoLite2-City.mmdb"
       add_field => [ "[geoip][coordinates]", "%{[geoip][longitude]}" ]
       add_field => [ "[geoip][coordinates]", "%{[geoip][latitude]}" ]
       # 去掉显示 geoip 显示的多余信息
       remove_field => ["[geoip][latitude]", "[geoip][longitude]", "[geoip][country_code]", "[geoip][country_code2]", "[geoip][country_code3]", "[geoip][timezone]", "[geoip][continent_code]", "[geoip][region_code]"]
     }

     mutate {
       convert => {
         "[size]" => "integer"
         "[status]" => "integer"
         "[responsetime]" => "float"
         "[upstreamtime]" => "float"
         "[geoip][coordinates]" => "float"
       }
     }

     # 根据http_user_agent来自动处理区分用户客户端系统与版本
     useragent {
       source => "http_user_agent"
       target => "ua"
       # 过滤useragent没用的字段
       remove_field => [ "[ua][minor]","[ua][major]","[ua][build]","[ua][patch]","[ua][os_minor]","[ua][os_major]" ]
     }
  }
}
output {
  stdout {
      codec => rubydebug
    }
  if [type] == "app" {
    elasticsearch {
      action => "index"
      hosts => ["http://$CURRENT_IP:9200"]
      user => "elastic"
      password => "Adkiwo49485Tidkw"
      index => "log-pro-app-%{[appName]}-%{+YYYY.MM.dd}"
    }
  }

  if [type] == "nginx" {
    elasticsearch {
      action => "index"
      hosts => ["http://$CURRENT_IP:9200"]
      user => "elastic"
      password => "Adkiwo49485Tidkw"
      index => "log-pro-nginx-%{[type]}-%{+YYYY.MM.dd}"
    }
  }
}

EOF
fi


# 配置並啟動 Logstash 容器
docker run -d  \
  --restart=always \
  --name logstash \
  --log-driver=json-file   \
  --log-opt max-size=10m   \
  --log-opt max-file=10   \
  -p 5506:5506 \
  -p 5044:5044 \
  -p 5046:5046 \
  -p 9600:9600  \
  -v "$LOGSTASH_DIR/logstash.conf:/usr/share/logstash/pipeline/logstash.conf" \
  -v "$GEOIP_DB_FILE:/usr/share/logstash/GeoLite2-City.mmdb"  \
  logstash:7.17.16


# 配置 Logstash 資料夾
KIBANA_DIR="/data/elk/kibana"
if [ ! -d "$KIBANA_DIR" ]; then
    mkdir -p "$KIBANA_DIR"
fi

# 配置 KIBANA yml 檔案
KIBA_YML_FILE="$KIBANA_DIR/kibana.yml"
if [ ! -f "$KIBA_YML_FILE" ]; then
    cat > "$KIBA_YML_FILE" << EOF
#设置Kibana映射端口
server.port: 5601
#设置网关地址
server.host: "0.0.0.0"
#设置Kibana实例对外展示的名称
server.name: "kibana"
#设置ES集群地址
elasticsearch.hosts: ["http://$CURRENT_IP:9200"]
#设置请求超时时长
elasticsearch.requestTimeout: 120000
#设置页面语言
i18n.locale: "zh-CN"
elasticsearch.username: "elastic"
elasticsearch.password: "Adkiwo49485Tidkw"
EOF
fi


# 配置並啟動 Kibana 容器
docker run -d \
  --restart=always \
  --name kibana \
  -v "$KIBANA_DIR/kibana.yml:/usr/share/kibana/config/kibana.yml" \
  -p 5601:5601 \
  kibana:7.17.16

#####等待服務上線
sleep 25
echo "等待服務上線大約25秒後設定refresh_interval"


####設定es所有index refresh_interval 30秒，預設是1秒
curl -X PUT -u elastic:Adkiwo49485Tidkw  "http://$CURRENT_IP:9200/_settings" -H 'Content-Type: application/json' -d '
{
"index": {
"refresh_interval": "30s"
}
}'

echo "ELK Stack is now running on http://$CURRENT_IP:5601"


logstash容器裡 config/logstash.yml
http.host: "0.0.0.0"
xpack.monitoring.enabled: true
xpack.monitoring.elasticsearch.username: elastic
xpack.monitoring.elasticsearch.password: Adkiwo49485Tidkw
xpack.monitoring.elasticsearch.hosts: [ "http://172.31.27.85:9200"]
