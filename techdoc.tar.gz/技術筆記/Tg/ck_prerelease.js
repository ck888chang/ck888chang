const child_process = require('child_process');

function formatMilliseconds(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(2);
    return `${minutes} 分 ${seconds} 秒`;
}

const nameSpace = {
    "dev_check":`goplaydev`,
    "test_check":`goplaytest`,
    "pre_check":`goplay`,
    "pro_check":`goplay`,   // 待確認名稱是否goplay
}

const deployCommands = {
    "dev_check":`kubectl get pods -n goplaydev`,
    "test_check":`kubectl get pods -n goplaytest`,
    "pre_check":`kubectl get pods -n goplay`,
    "pro_check":`kubectl get pods -n goplay`,   // 待確認名稱是否goplay
}

const comMsg = {
    "com": "环境所有服务的k8s状态查看完成",
    // 其他通用信息
}

const afterTips = {
    "dev_check":`Hi! 检查[develop]开发${comMsg["com"]}`,
    "test_check":`Hi! 检查[test]测试${comMsg["com"]}`,
    "pre_check":`Hi! 检查[prerelease]預發${comMsg["com"]}`,
    "pro_check":`Hi! 检查[Production]生產${comMsg["com"]}`,
}

// 定義你的 dev_autocheck 方法
module.exports.autocheck = async (bot, chatId, funName, omsg) => {
    let startTime = Date.now();
    let logMsg = child_process.execSync(deployCommands[funName]).toString();
    let endTime = Date.now();
    let executionTime = endTime - startTime;

    // 判斷是否包含 "CrashLoopBackOff"
    if (logMsg.includes("CrashLoopBackOff") || logMsg.includes("Pending") || logMsg.includes("Error")) {

        // 解析 logMsg，找到异常的 pod 信息
        const podInfoRegex = /(\S+)-\d+\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/g;
        let match;
        let errorPods = [];

        while ((match = podInfoRegex.exec(logMsg)) !== null) {
            const podName = match[1];
            const status = match[3];
            const restarts = parseInt(match[4]);
            const age = match[5];

            if (status === "CrashLoopBackOff" || status === "Pending" || status === "Error") {
                errorPods.push({ podName, status, restarts, age });
            }
        }
        // 生成符合格式的异常信息
        if (errorPods.length > 0) {
            let errorMsg = `机器人自动检查k8s命令空间[${nameSpace[funName]}] 下面 pod 运行异常：\n`;

            errorPods.forEach((pod) => {
                errorMsg += `Pod名称:[${pod.podName}], 异常状态: [ ${pod.status} ], 重启次数: [ ${pod.restarts} ], 持续时间: [ ${pod.age} ]\n`;
            });

        let msg = `@${omsg.from.username}
${afterTips[funName]},日志如下
${errorMsg}
@God_Ridiculous @kingofmakati @kenops2023 @ck_ops
本次执行时间，耗时: ${formatMilliseconds(executionTime)}
`;
        await bot.sendMessage(chatId, msg);
        }else{
            //await bot.sendMessage(chatId, "定時檢查完成，正常");
            console.error("定時檢查完成，正常");
        }
    }
}