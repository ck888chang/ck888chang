
const child_process = require('child_process');
//const afterTips = require('./goplaydeploy').afterTips;  // 這裡要確保相對路徑正確

function formatMilliseconds(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(2);
    return `${minutes} 分 ${seconds} 秒`;
};

const nameSpace = {
    "dev_check":`goplaydev`,
    "test_check":`goplaytest`,
    "pre_check":`goplay`,
    "pro_check":`goplay`,   // 待確認名稱是否goplay
};

const deployCommands = {
    "dev_check":`kubectl get pods -n goplaydev`,
    "test_check":`kubectl get pods -n goplaytest`,
    "pre_check":`kubectl get pods -n goplay`,
    "pro_check":`kubectl get pods -n goplay`,   // 待確認名稱是否goplay
};

const comMsg = {
    "com": "环境所有服务的k8s状态查看完成",
    // 其他通用信息
};

const afterTips = {
    "dev_check":`Hi! 检查[develop]开发${comMsg["com"]}`,
    "test_check":`Hi! 检查[test]测试${comMsg["com"]}`,
    "pre_check":`Hi! 检查[prerelease]預發${comMsg["com"]}`,
    "pro_check":`Hi! 检查[Production]生產${comMsg["com"]}`,
};

// 定義你的 dev_autocheck 方法

module.exports.autocheck = async (bot, chatId, funName, omsg) => {
    let startTime = Date.now();
    let logMsg = child_process.execSync(deployCommands[funName]).toString();
    let endTime = Date.now();
    let executionTime = endTime - startTime;

    // 判斷是否包含 "CrashLoopBackOff"
    if (logMsg.includes("CrashLoopBackOff") || logMsg.includes("Pending") || logMsg.includes("Error")) {

        // 解析 logMsg，找到异常的 pod 信息
        //const podInfoRegex = /(\S+)-\d+\/\d+\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/g;
        const podInfoRegex = /(\S+)-\d+\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/g;
        const podInfoRegex = /(\S+)-\d+\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/g;

        let match;
        let errorPods = [];

        while ((match = podInfoRegex.exec(logMsg)) !== null) {
            const podName = match[1];
            const status = match[3];
            const restarts = parseInt(match[4]);
            const age = match[5];

            if (status === "CrashLoopBackOff" || status === "Pending" || status === "Error") {
                errorPods.push({ podName, status, restarts, age });
            }
        }
        console.log('errorPods message:',errorPods);
        // 生成符合格式的异常信息
        if (errorPods.length > 0) {
            let errorMsg = `机器人自动 检查 k8s 命令空间[${nameSpace[funName]}] 下面 pod 运行异常：`;

            errorPods.forEach((pod) => {
                errorMsg += `Pod名称: [${pod.podName}], 异常状态: [${pod.status}], 重启次数: [${pod.restarts}], 持续时间: [${pod.age}]\n`;
            });


        let msg = `@${omsg.from.username}
${afterTips[funName]},日志如下
${errorMsg}
@God_Ridiculous @kingofmakati @kenops2023 @ck_ops
本次执行时间，耗时: ${formatMilliseconds(executionTime)}
`;
        await bot.sendMessage(chatId, msg);
        console.log(msg);
    }else{
    //console.log('Received message with chatId:', chatId);
    //console.log('Received message with bot', bot);
        try {
            console.log('Received message with chatId:', chatId);
            //await bot.sendMessage(chatId, "定時檢查完成，正常");  //需要時才開啟
        } catch (error) {
            console.error('Error sending message:', error);
            console.error('Error details:', error.response.body);
        }
        console.log('Executing interval code3333');
    }
    // 如果不包含 "CrashLoopBackOff" 則不做任何動作
}
}








//############### 在主程式需要引入
const ckModule = require('./lib/ck');

// 其他引入和設定...

// 定時任務
// 設置每小時執行一次 dev_autocheck
const interval = 60 * 60 * 1000; // 60分鐘 * 60秒 * 1000毫秒
setInterval(async () => {
    const chatId = authChatIds[1];
    // 在這裡使用 ckModule 中的功能，例如 ckModule.dev_autocheck
    await ckModule.autocheck(bot, chatId, "pre_check", {
        from: { username: "system" }, // 可以隨意指定一個假的使用者
    } );
}, interval); // 每小時執行一次

// 其他程式邏輯...




机器人自动 检查 k8s 命令空间[goplaytest] 下面 pod [merchant-service-deploy-789d76f544-v77g5] 运行异常，异常状态[CrashLoopBackOff]，持续时间 [9m35s], 请解决 ！




//################################## 以下為歷史，沒用的

NAME                                                           READY   STATUS    RESTARTS        AGE
fluent-bit-4vqz2                                               1/1     Running   1 (4d22h ago)   5d4h
fluent-bit-8459v                                               1/1     Running   0               5d4h
fluentbit-operator-6bdf9d4475-7qhpb                            1/1     Running   0               5d4h
logsidecar-injector-deploy-56f59bcbcf-fd6k4                    2/2     Running   0               5d4h
logsidecar-injector-deploy-56f59bcbcf-wbpn8                    2/2     Running   0               5d4h
opensearch-cluster-data-0                                      0/1     Pending   0               5d4h
opensearch-cluster-data-1                                      0/1     Pending   0               5d4h
opensearch-cluster-master-0                                    0/1     Pending   0               5d4h
opensearch-logging-curator-opensearch-curator-28412700-jxclb   0/1     Error     0               22h
opensearch-logging-curator-opensearch-curator-28412700-m9r25   0/1     Error     0               22h
opensearch-logging-curator-opensearch-curator-28412700-p5vxn   0/1     Error     0               22h
opensearch-logging-curator-opensearch-curator-28412700-pmg9w   0/1     Error     0               22h
opensearch-logging-curator-opensearch-curator-28412700-smdsl   0/1     Error     0               22h
opensearch-logging-curator-opensearch-curator-28412700-x2j8t   0/1     Error     0               21h
opensearch-logging-curator-opensearch-curator-28412700-xhgs7   0/1     Error     0               22h




NAME                                          READY   STATUS    RESTARTS     AGE
api-service-deploy-f4985cbc7-n4lfl            1/1     Running   0            15h
back-service-deploy-59bbf96fb8-fhkzn          1/1     Running   0            38h
dashboard-deploy-7f7fdb5fb5-qksrr             1/1     Running   1 (8d ago)   11d
game-service-deploy-674bbf8f56-slxcx          1/1     Running   0            4d12h
goplay-h5-deploy-787c9d5cd7-zmbkw             1/1     Running   0            8h
goplay-web-admin-deploy-6595d8b78b-l46sl      1/1     Running   0            4d20h
goplay-web-merchant-deploy-6658c88f68-4kbqh   1/1     Running   0            8h
gp-payment-service-deploy-86dfd7bf46-dk5w4    1/1     Running   0            43h
merchant-service-deploy-77b69b888f-9pgpx      1/1     Running   0            13h
push-service-deploy-6d976cc9c8-ghljw          1/1     Running   0            4d12h
task-service-deploy-5cc8f4d688-d8tdq          1/1     Running   0            11h







// 新增 dev_autocheck 函數
module.exports.dev_autocheck = async (bot, chatId, funName, omsg) => {
    let startTime = Date.now();
    let logMsg = child_process.execSync(deployCommands["dev_check"]).toString();
    let endTime = Date.now();
    let executionTime = endTime - startTime;

    // 判斷是否包含 "CrashLoopBackOff"
    if (logMsg.includes("CrashLoopBackOff")) {
        let msg = `@${omsg.from.username}
${afterTips["dev_check"]},日志如下
${logMsg}
本次执行时间，耗时: ${formatMilliseconds(executionTime)}
`;
        await bot.sendMessage(chatId, msg);
    }
    // 如果不包含 "CrashLoopBackOff" 則不做任何動作
};

// 將 dev_autocheck 加入 allowedFuns 陣列
allowedFuns.push("dev_autocheck");

// 設置每小時執行一次 dev_autocheck
const interval = 60 * 60 * 1000; // 60分鐘 * 60秒 * 1000毫秒
setInterval(async () => {
    // 取得當前時間，用於顯示
    const currentTime = new Date().toLocaleString();

    // 呼叫 dev_autocheck
    await module.exports.dev_autocheck(bot, chatId, "dev_autocheck", {
        from: { username: "system" }, // 可以隨意指定一個假的使用者
    });

    // 發送訊息到 Telegram 群組
    await bot.sendMessage(chatId, `定時任務已執行，當前時間: ${currentTime}`);
}, interval);