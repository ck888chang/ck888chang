// ### program in here
//root@slots-test-main:/home/jnodes/slots_deploy_tg# cat test_slots_deploy_tg.js

const TelegramBot = require('node-telegram-bot-api');
const util = require('util');
const moment = require("moment");
const child_process = require('child_process');
const yaml = require('js-yaml');
const fs = require('fs');
const { Worker } = require('worker_threads');

const token = '6412559730:AAGp63hSmQKpNJ8FRqYn7_TA3dxcPKP2x0A';

const authChatIds = [6553682453,-4074716871];

const unAthInfo = "你的信息已记录，请联系管理员授权!";

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function inArray(search, array) {
    for (var i in array) {
        if (array[i] == search) {
            return true;
        }
    }
    return false;
}

function formatMilliseconds(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(2);
    return `${minutes} 分 ${seconds} 秒`;
}

const bot = new TelegramBot(token, {
    polling: true
});


let commandArr = {
    "GateServer":{
        'bftips':'',
        'cmd':``,
        'aftips':'',
    },
    'HallServer':{},
    'st_ad_sv':{
        'bftips':'收到！正在执行发布slots-server-admin test分支到Test环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.14.5:6007/deploy'  \
        --header 'token: f2b2e1232868cbfe9980b6dfd87e23ce2dc101' \
        --header 'Content-Type: application/x-www-form-urlencoded'  \
        --data-urlencode 'branch=test'`,
        'aftips':'Hi! 发布slots-server-admin test分支到Test环境完成',
    },

    'st_ad_wb':{
        'bftips':'收到！正在执行发布slot-web-admin test分支到Test环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.14.5:6006/deploy'  \
        --header 'token: 10me12868cbfe9980b6dfd87e23ce2dc1' \
        --header 'Content-Type: application/x-www-form-urlencoded'  \
        --data-urlencode 'branch=test'`,
        'aftips':'Hi! 发布slots-web-admin test分支到Test环境完成',
    },

    'st_mc_sv':{
        'bftips':'收到！正在执行发布slots-server-merchat test分支到Test环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.14.5:6004/deploy'  \
        --header 'token: f2b2e12868cbfe9980b6dfd87e23ce2dc101' \
        --header 'Content-Type: application/x-www-form-urlencoded'  \
        --data-urlencode 'branch=test'`,
        'aftips':'Hi! 发布slots-server-merchat test分支到Test环境完成',
    },



    'st_mc_wb':{
        'bftips':'收到！正在执行发布slot-web-merchant test分支到Test环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.14.5:6005/deploy'  \
        --header 'token: fbme12868cbfe9980b62dfd87e23ce2dc1' \
        --header 'Content-Type: application/x-www-form-urlencoded'  \
        --data-urlencode 'branch=test'`,
        'aftips':'Hi! 发布slots-web-merchant test分支到Test环境完成',
    },

    'st_mc_api':{
        'bftips':'收到！正在执行发布solts-api-merchant test分支到Test环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.14.5:6002/deploy'  \
        --header 'token: f2be12868cbfe9980b6dfd87e23ce2dc1' \
        --header 'Content-Type: application/x-www-form-urlencoded'  \
        --data-urlencode 'branch=test'`,
        'aftips':'Hi! 发布solts-api-merchant test分支到Test环境完成',
    },

    'st_of_wb':{
        'bftips':'收到！正在执行发布slots-web-official test分支到Test环境，请稍等1-8分钟...',
        'cmd':`curl --location 'http://172.31.14.5:6003/deploy'  \
        --header 'token: fbme12868cbfe9980b6dfd87e23ce2dc1' \
        --header 'Content-Type: application/x-www-form-urlencoded'  \
        --data-urlencode 'branch=test'`,
        'aftips':'Hi! 发布slots-web-official test分支到Test环境完成',
    },

    'test_status':{
        'bftips':'收到！正在执行发布k8s状态检查，请稍等...',
        'cmd':`kubectl get pods -n slotstest`,
        'aftips':'Hi! 执行发布k8s状态检查完成',
    }
}


const yamlData = fs.readFileSync('consts.yaml', 'utf8');
const parsedData = yaml.load(yamlData);


const SpecialGameServers = parsedData["SpecialGameServers"];
const GameServers = parsedData["GameServers"];
const MiniGameServers = parsedData["MiniGameServers"];
const MainServers =  parsedData["MainServers"];

let serverNameStr='';
let slotsAllGameServers = [];
for(var gserver of MainServers){
    serverNameStr += gserver+',';
    commandArr[gserver] = {};
    slotsAllGameServers.push(gserver);
}
for(var gserver of GameServers){
    serverNameStr += gserver+',';
    commandArr[gserver] = {};
    slotsAllGameServers.push(gserver);
}
for(var gserver of MiniGameServers){
    serverNameStr += gserver+',';
    commandArr[gserver] = {};
    slotsAllGameServers.push(gserver);
}
for(var gserver of SpecialGameServers){
    serverNameStr += gserver+',';
    commandArr[gserver] = {};
    slotsAllGameServers.push(gserver);
}

serverNameStr = serverNameStr.substr(0, serverNameStr.length - 1);

const envName='测试环境';
const branchName='test';

const helpMsg = `Only:
\/st_ad_sv       [在${envName}发布Server-Admin项目于${branchName}分支]

\/st_ad_wb       [在${envName}发布Slots-Web-Admin项目于${branchName}分支]

\/st_mc_sv       [在${envName}发布Server-Merchant项目于${branchName}分支]

\/st_mc_wb       [在${envName}发布Slots-Web-Merchant项目于${branchName}分支]

\/st_mc_api      [在${envName}发布Server-merchant-api项目于${branchName}分支]

\/st_of_wb       [在${envName}发布Slots-Web-Official项目于${branchName}分支]

\/gd deploy 游戏服务名 [在${envName}发布Slots-Games-Go-API项目于${branchName}分支,游戏服务名有:${serverNameStr};示例 \/gd deploy GateServer]

\/gAll  [在${envName}发布Slots-Games-Go-API项目于${branchName}分支,所有游戏服务]

\/test_status   [检查${envName}k8s状态]
`

bot.onText(/\/help/, async msg => {
    console.log(msg);
    const chatId = msg.chat.id;

    if (inArray(chatId, authChatIds)) {
        // 确认授权的群，发送help提示
        await bot.sendMessage(chatId, helpMsg);
    } else {
        //非授权提示
        await bot.sendMessage(chatId, unAthInfo);
    }
});

const commonTips = {
    'gd-deploy':{
        'bftips':`收到！正在执行发布Slots-Games-Go-API 的 %s 的 ${branchName}分支到${envName}，请稍等1-6分钟...`,
        'aftips':`Hi! 发布Slots-Games-Go-API的%s于分支[${branchName}]${envName}完成`,
    },
    'gd-deploy-all':{
        'bftips':`收到！正在执行发布Slots-Games-Go-API 的所有服务的${branchName}分支到${envName}，请稍等10-%s分钟...`,
        'aftips':`Hi! 发布Slots-Games-Go-API的所有服务于分支[${branchName}]${envName}完成`,
    }
}


const commondCommandS = {
    'gd-deploy':{
         'cmd':` curl -s --location 'http://172.31.14.5:6008/deploy' \
          --header 'token: f2be12868cbfe9980b6dfd87e23ce2dc1' \
          --header 'Content-Type: application/x-www-form-urlencoded' \
          --data-urlencode 'branch=${branchName}' \
          --data-urlencode 'gameCode=%s'`
    }
 }


async function gameServerDeploy(chatId,username,gameServer,typeAll=false){
    let cTime = moment();
    if(!typeAll){
        if(commandArr[gameServer]['bftips']){
            await bot.sendMessage(chatId, commandArr[gameServer]['bftips']);
        }else{
            await bot.sendMessage(chatId, util.format(commonTips[`gd-deploy`]['bftips'], gameServer));
        }
    }


    let aftips = '';
    if(commandArr[gameServer]['aftips']){
        aftips = commandArr[gameServer]['aftips'];
    }else{
        aftips = util.format(commonTips[`gd-deploy`]['aftips'], gameServer);
    }

    let startTime = Date.now();
    let command = '';
    if(commandArr[gameServer]['cmd']){
        command = commandArr[gameServer]['cmd'];
    }else{
        command =  util.format(commondCommandS[`gd-deploy`]['cmd'], gameServer)
    }
    console.log("执行",command)
    let clogMsg = child_process.execSync(command).toString().trim();
    let endTime = Date.now();
    let executionTime = endTime - startTime;
    let sendFileName = `./deploy-logs/${username}-${gameServer}-deploy-${cTime.format('YYYY-MM-DD-HH-mm-ss')}.txt`;
    fs.writeFileSync(sendFileName, clogMsg);
    let outmsg = '';
    //if(!typeAll){
        outmsg =`@${username}
${aftips},日志文件如下`;
        await bot.sendMessage(chatId, outmsg);
    //}

    if(clogMsg.endsWith('发布成功')){
        await bot.sendDocument(chatId, sendFileName, {
            contentType: 'text/plain',
        });
        await bot.sendMessage(chatId, '<strong>发布成功</strong>', {parse_mode: 'HTML'});
    }else{
        await bot.sendDocument(chatId, sendFileName, {
            contentType: 'text/plain',
        });
        await bot.sendMessage(chatId, '<strong><code>发布失败</code></strong>', {parse_mode: 'HTML'});
    }
    //if(!typeAll){
        outmsg =`本次执行时间，耗时: ${formatMilliseconds(executionTime)}`;
        await bot.sendMessage(chatId, outmsg);
    //}

}

bot.onText(/\/gd(.+)/, async (msg, match) => {
    var resp = match[1].trim();
    console.log(msg,match);
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {
        let paramsArr =  resp.split(" ").filter(e=>e.trim());
        if(paramsArr.length != 2){
            paramsArr =  resp.split("_").filter(e=>e.trim());
        }
        if(paramsArr.length == 2){
            if(paramsArr[0] == "deploy"){
                if(!commandArr[paramsArr[1]]){
                    await bot.sendMessage(chatId, ' \/gd deploy 命令的服务名错误!');
                    return;
                }
                let gameServer = paramsArr[1];
                await gameServerDeploy(chatId,msg.from.username,gameServer);
            }
        }
    }
});


bot.onText(/\/(gAll)/,async (msg, match) => {
    var resp = match[1].trim();
    console.log(msg,match);
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {
        let startTime = Date.now();
        await bot.sendMessage(chatId,  util.format(commonTips[`gd-deploy-all`]['bftips'], slotsAllGameServers.length));
        let typeAll = true;
        for(let i=0 ; i <  slotsAllGameServers.length ; i++){
            let workers = [];

            // worker1
            let gServerName = slotsAllGameServers[i];
            workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));

            // worker2
            i++;
            if(i<slotsAllGameServers.length){
                let gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));
            }

            // worker3
            i++;
            if(i<slotsAllGameServers.length){
                let gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));
            }

            // worker4
            i++;
            if(i<slotsAllGameServers.length){
                let gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));
            }

            // worker5
            i++;
            if(i<slotsAllGameServers.length){
                let gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));
            }

            // worker6
            i++;
            if(i<slotsAllGameServers.length){
                let gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));
            }

            // worker7
            i++;
            if(i<slotsAllGameServers.length){
                let gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));
            }

            // worker8
            i++;
            if(i<slotsAllGameServers.length){
                let gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));
            }

            // worker9
            i++;
            if(i<slotsAllGameServers.length){
                let gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));
            }

            // worker10
            i++;
            if(i<slotsAllGameServers.length){
                let gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId,username:msg.from.username,gameServer:gServerName} }));
            }

            let workdersMap = [];
            for(var j = 0 ; j < workers.length ; j++){
                workers[j].on('message', (message) => {
                    console.log(`工作线程1 发送消息: ${message}`);
                });
                workdersMap.push(new Promise((resolve) => workers[j].on('exit', resolve)))
            }
            await Promise.all(workdersMap);
        }
        await bot.sendMessage(chatId, commonTips[`gd-deploy-all`]['aftips']);
        let endTime = Date.now();
        let executionTime = endTime - startTime;
        outmsg =`本次执行Slots-Games-Go-API项目所有服务发布时间，耗时: ${formatMilliseconds(executionTime)}`;
        await bot.sendMessage(chatId, outmsg);
    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});



bot.onText(/\/(st_ad_sv|st_ad_wb|st_mc_sv|st_mc_wb|st_mc_api|st_of_wb|test_status)/,async (msg, match) => {
    var resp = match[1].trim();
    console.log(msg,match);
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {
        await bot.sendMessage(chatId, commandArr[match[1]]['bftips']);
        let startTime = Date.now();
        let command = commandArr[match[1]]['cmd'];
        let aftips = commandArr[match[1]]['aftips'];
        console.log("执行",command)
        let clogMsg = child_process.execSync(command).toString();
        let endTime = Date.now();
        let executionTime = endTime - startTime;

        let outmsg =`@${msg.from.username}
${aftips},日志如下
${clogMsg}
本次执行时间，耗时: ${formatMilliseconds(executionTime)}
`;
        await bot.sendMessage(chatId, outmsg);

    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});