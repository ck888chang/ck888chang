
// 程式所在位置goplay-test-main:/home/jenkins/goplay-deploy-tg/goplay-admin-deploy-tg-dev.js
// [root@goplay-test-main goplay-deploy-tg]# cat goplay-admin-deploy-tg-dev.js

const TelegramBot = require('node-telegram-bot-api');
const token = '6383721110:AAHyZOaXJx6aZ45iZQy0iEcvj6jv61PTN5o';

const deploy = require('./lib/goplaydeploy');
const ckModule = require('./lib/ck');

const authChatIds = [5021287957,-1002115608016];

const unAthInfo = "你的信息已记录，请联系管理员授权!";

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function inArray(search, array) {
    for (var i in array) {
        if (array[i] == search) {
            return true;
        }
    }
    return false;
}

const bot = new TelegramBot(token, {
    polling: true
});

const helpMsg = `Only:
        \/dev_check       [检查开发环境所有服务的k8s状态查看]
        \/dev_api         [发布goplay-admin 的api-service       于develop分支]
        \/dev_back        [发布goplay-admin 的back-service      于develop分支]
        \/dev_game        [发布goplay-admin 的game-service      于develop分支]
        \/dev_merchant    [发布goplay-admin 的merchant-service  于develop分支]
        \/dev_push        [发布goplay-admin 的push-service      于develop分支]
        \/dev_task        [发布goplay-admin 的task-service      于develop分支]
        \/dev_gp_pay      [发布gp-payment-service      于develop分支]

        \/dev_restart_api      [重启goplay-admin 的api-service        于develop分支]
        \/dev_restart_back     [重启goplay-admin 的back-service       于develop分支]
        \/dev_restart_game     [重启goplay-admin 的game-service       于develop分支]
        \/dev_restart_merchant [重启goplay-admin 的merchant-service   于develop分支]
        \/dev_restart_push     [重启goplay-admin 的push-service       于develop分支]
        \/dev_restart_task     [重启goplay-admin 的task-service       于develop分支]
        \/dev_restart_gp_pay   [重启gp-payment-service       于develop分支]

        \/dev_config_api      [获取goplay-admin 的api-service  develop yaml config]
        \/dev_config_back     [获取goplay-admin 的back-service  develop yaml config]
        \/dev_config_game     [获取goplay-admin 的game-service  develop yaml config]
        \/dev_config_merchant [获取goplay-admin 的merchant-service  develop yaml config]
        \/dev_config_push     [获取goplay-admin 的push-service  develop yaml config]
        \/dev_config_task     [获取goplay-admin 的task-service  develop yaml config]
        \/dev_config_gp_pay   [获取gp-payment-service  develop yaml config]

        \/dev_redis_flushdb    [清空开发环境的redis库]
        \/dev_redis   params   [执行开发环境中的redis指令：例如  \/dev_redis keys *]

        \/test_check      [检查测试环境所有服务的k8s状态查看]
        \/test_api        [发布goplay-admin 的api-service        于test分支]
        \/test_back       [发布goplay-admin 的back-service       于test分支]
        \/test_game       [发布goplay-admin 的game-service       于test分支]
        \/test_merchant   [发布goplay-admin 的merchant-service   于test分支]
        \/test_push       [发布goplay-admin 的push-service       于test分支]
        \/test_task       [发布goplay-admin 的task-service       于test分支]
        \/test_gp_pay     [发布gp-payment-service      于test分支]

        \/test_restart_api      [重启goplay-admin 的api-service        于test分支]
        \/test_restart_back     [重启goplay-admin 的back-service       于test分支]
        \/test_restart_game     [重启goplay-admin 的game-service       于test分支]
        \/test_restart_merchant [重启goplay-admin 的merchant-service   于test分支]
        \/test_restart_push     [重启goplay-admin 的push-service       于test分支]
        \/test_restart_task     [重启goplay-admin 的task-service       于test分支]
        \/test_restart_gp_pay   [重启gp-payment-service       于test分支]

        \/test_config_api      [获取goplay-admin 的api-service  test yaml config]
        \/test_config_back     [获取goplay-admin 的back-service  test yaml config]
        \/test_config_game     [获取goplay-admin 的game-service  test yaml config]
        \/test_config_merchant [获取goplay-admin 的merchant-service  test yaml config]
        \/test_config_push     [获取goplay-admin 的push-service  test yaml config]
        \/test_config_task     [获取goplay-admin 的task-service  test yaml config]
        \/test_config_gp_pay   [获取gp-payment-service  test yaml config]

        \/test_redis_flushdb    [清空测试环境的redis库]
        \/test_redis   params   [执行开发环境中的redis指令：例如  \/test_redis keys *]
`;


/*bot.onText(/\/help/, async msg => {
    if (msg.text !== "/help") {
        return;
    }
    const chatId = msg.chat.id;

    if (inArray(chatId, authChatIds)) {
        await bot.sendMessage(chatId, helpMsg);
    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});*/

const allowedMsg1 = ["/dev_check","/dev_api","/dev_back","/dev_game","/dev_merchant","/dev_pay","/dev_push","/dev_task",
                    "/dev_restart_api","/dev_restart_back","/dev_restart_game","/dev_restart_merchant","/dev_restart_pay","/dev_restart_push","/dev_restart_task",
                    "/dev_config_api","/dev_config_back","/dev_config_game","/dev_config_merchant","/dev_config_pay","/dev_config_push","/dev_config_task",
                    "/dev_redis_flushdb","/dev_gp_pay","/dev_restart_gp_pay","/dev_config_gp_pay"]

 const allowedMsg2 = ["/test_check","/test_api","/test_back","/test_game","/test_merchant","/test_pay","/test_push","/test_task",
                    "/test_restart_api","/test_restart_back","/test_restart_game","/test_restart_merchant","/test_restart_pay","/test_restart_push","/test_restart_task",
                    "/test_config_api","/test_config_back","/test_config_game","/test_config_merchant","/test_config_pay","/test_config_push","/test_config_task",
                    "/test_redis_flushdb","/test_gp_pay","/test_restart_gp_pay","/test_config_gp_pay"];

const beforeTips = {
    "dev_check":"收到！正在执行检查开发环境所有服务的k8s状态查看，请稍等...",
    "dev_api":"收到！正在执行发布goplay-admin 的 api-service 的 develop分支到开发环境，请稍等1-6分钟...",
    "dev_back":"收到！正在执行发布goplay-admin 的 back-service 的 develop分支到开发环境，请稍等1-6分钟...",
    "dev_game":"收到！正在执行发布goplay-admin 的 game-service 的 develop分支到开发环境，请稍等1-6分钟...",
    "dev_merchant":"收到！正在执行发布goplay-admin 的 merchant-service 的 develop分支到开发环境，请稍等1-6分钟...",
    "dev_push":"收到！正在执行发布goplay-admin 的 push-service 的 develop分支到开发环境，请稍等1-6分钟...",
    "dev_task":"收到！正在执行发布goplay-admin 的 task-service 的 develop分支到开发环境，请稍等1-6分钟...",
    "dev_gp_pay":"收到！正在执行发布gp-payment-service 的 develop分支到开发环境，请稍等1-6分钟...",

    "dev_restart_api":"收到！重启goplay-admin的api-service于[develop]开发环境，请稍等...",
    "dev_restart_back":"收到！重启goplay-admin的back-service于[develop]开发环境，请稍等...",
    "dev_restart_game":"收到！重启goplay-admin的game-service于[develop]开发环境，请稍等...",
    "dev_restart_merchant":"收到！重启goplay-admin的merchant-service于[develop]开发环境，请稍等...",
    "dev_restart_push":"收到！重启goplay-admin的push-service于[develop]开发环境，请稍等...",
    "dev_restart_task":"收到！重启goplay-admin的task-service于[develop]开发环境，请稍等...",
    "dev_restart_gp_pay":"收到！重启gp-payment-service于[develop]开发环境，请稍等...",

    "dev_config_api":"收到！获取goplay-admin的api-service  develop yaml config，请稍等...",
    "dev_config_back":"收到！获取goplay-admin的back-service  develop yaml config，请稍等...",
    "dev_config_game":"收到！获取goplay-admin的game-service  develop yaml config，请稍等...",
    "dev_config_merchant":"收到！获取goplay-admin的merchant-service  develop yaml config，请稍等...",
    "dev_config_push":"收到！获取goplay-admin的push-service  develop yaml config，请稍等...",
    "dev_config_task":"收到！获取goplay-admin的task-service  develop yaml config，请稍等...",
    "dev_config_gp_pay":"收到！获取gp-payment-service  develop yaml config，请稍等...",

    "dev_redis_flushdb":"收到！正在清空开发环境的redis库,请稍等...",
    "dev_redis":"收到！正在执行开发环境的redis指令,请稍等...",

    "test_check":"收到！正在执行检查测试环境所有服务的k8s状态查看，请稍等...",
    "test_api":"收到！正在执行发布goplay-admin 的 api-service 的 test分支到开发环境，请稍等1-6分钟...",
    "test_back":"收到！正在执行发布goplay-admin 的 back-service 的 test分支到开发环境，请稍等1-6分钟...",
    "test_game":"收到！正在执行发布goplay-admin 的 game-service 的 test分支到开发环境，请稍等1-6分钟...",
    "test_merchant":"收到！正在执行发布goplay-admin 的 merchant-service 的 test分支到开发环境，请稍等1-6分钟...",
    "test_push":"收到！正在执行发布goplay-admin 的 push-service 的 test分支到开发环境，请稍等1-6分钟...",
    "test_task":"收到！正在执行发布goplay-admin 的 task-service 的 test分支到开发环境，请稍等1-6分钟...",
    "test_gp_pay":"收到！正在执行发布gp-payment-service 的 test分支到开发环境，请稍等1-6分钟...",

    "test_restart_api":"收到！重启goplay-admin的api-service于[test]开发环境，请稍等...",
    "test_restart_back":"收到！重启goplay-admin的back-service于[test]开发环境，请稍等...",
    "test_restart_game":"收到！重启goplay-admin的game-service于[test]开发环境，请稍等...",
    "test_restart_merchant":"收到！重启goplay-admin的merchant-service于[test]开发环境，请稍等...",
    "test_restart_push":"收到！重启goplay-admin的push-service于[test]开发环境，请稍等...",
    "test_restart_task":"收到！重启goplay-admin的task-service于[test]开发环境，请稍等...",
    "test_restart_gp_pay":"收到！重启gp-payment-service于[test]开发环境，请稍等...",

    "test_config_api":"收到！获取goplay-admin的api-service  test yaml config，请稍等...",
    "test_config_back":"收到！获取goplay-admin的back-service  test yaml config，请稍等...",
    "test_config_game":"收到！获取goplay-admin的game-service  test yaml config，请稍等...",
    "test_config_merchant":"收到！获取goplay-admin的merchant-service  test yaml config，请稍等...",
    "test_config_push":"收到！获取goplay-admin的push-service  test yaml config，请稍等...",
    "test_config_task":"收到！获取goplay-admin的task-service  test yaml config，请稍等...",
    "test_config_gp_pay":"收到！获取gp-payment-service  test yaml config，请稍等...",

    "test_redis_flushdb":"收到！正在清空测试环境的redis库,请稍等...",
    "test_redis":"收到！正在执行测试环境的redis指令,请稍等...",
}

bot.on('message', async msg => {
    console.log(msg);
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {
        if(msg.text){
            var msgText= msg.text.trim();
            msgText = msgText.replace("@goplay_admin_deploy_bot","");
            msgText = msgText.replace("@goplay_admin_deploy_bot","");
            if(inArray(msgText,allowedMsg1)){
                var funName = msgText.replace("/","").trim();
                await bot.sendMessage(chatId, beforeTips[funName]);
                deploy[funName](bot,chatId,funName,msg);
            }
            /*if(inArray(msgText,allowedMsg2)){
                var funName = msgText.replace("/","").trim();
                await bot.sendMessage(chatId, beforeTips[funName]);
                deploy[funName](bot,chatId,funName,msg);
            }*/
            /*else{
                await bot.sendMessage(chatId, helpMsg);
            }*/
        }
    }else{
        await bot.sendMessage(chatId, unAthInfo);
    }
});




bot.onText(/\/dev_redis (.+)/, async (msg, match) => {
    const funName = "dev_redis";
    var resp = match[1].trim();
    console.log(match);
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {
        await bot.sendMessage(chatId, beforeTips[funName]);
        deploy[funName](bot,chatId,funName,msg,resp);
    }
});

/*bot.onText(/\/test_redis (.+)/, async (msg, match) => {
    const funName = "test_redis";
    var resp = match[1].trim();
    console.log(match);
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {
        await bot.sendMessage(chatId, beforeTips[funName]);
        deploy[funName](bot,chatId,funName,msg,resp);
    }
});*/


const interval = 60 * 60 * 1000; // 60分鐘 * 60秒 * 1000毫秒
setInterval(async () => {
    console.log('Executing interval code');
    const chatId = authChatIds[1];
    // 在這裡使用 ckModule 中的功能，例如 ckModule.dev_autocheck
    await ckModule.dev_autocheck(bot, chatId, "dev_check",{from: { username: "system" }} );
}, interval); // 每小時執行一次