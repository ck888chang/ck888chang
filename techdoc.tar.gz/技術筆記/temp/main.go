/*
file location main主機/data/aniki/nginx-config/main.go
*/


package main

import (
        "fmt"
        "net/http"
        "os/exec"

        "nginx-config/pkg"
        "nginx-config/pkg/logger"
        "nginx-config/routers"

        _ "github.com/codyguo/godaemon"
        "github.com/gin-gonic/gin"
)

func main() {
        gin.SetMode("debug")
        if _, err := exec.LookPath("nginx"); err != nil {
                logger.Error("未找到Nginx命令，请确保Nginx已正确安装并已添加到系统路径中。")
        }
        routersInit := routers.InitRouter()
        maxHeaderBytes := 1 << 20

        endPoint := fmt.Sprintf(":%d", pkg.Conf.Server.Port)
        logger.Info("启动成功")
        server := &http.Server{
                Addr:           endPoint,
                Handler:        routersInit,
                ReadTimeout:    pkg.Conf.Server.ReadTimeout,
                WriteTimeout:   pkg.Conf.Server.WriteTimeout,
                MaxHeaderBytes: maxHeaderBytes,
        }

        _ = server.ListenAndServe()
}