#!/bin/bash

echo "test.."

runSendMessage(){
  local time="$1"
  local project_env="$2"
  local daysTime="$3"

  curl -X POST \
     -H 'Content-Type: application/json' \
     -d '{"chat_id": "-4093063436", "text":"执行时间: '"${time}"' UTC  \n执行环境: '"${project_env}"' \n执行任务: 清理'"${project_env}"''"${daysTime}"'的Java程序日志数\n执行状态：完成", "disable_notification": true}' \
     https://api.telegram.org/bot6818519410:AAFgPkDW9PIGVfHJY5cgFornHndqExYu6do/sendMessage
}

deleteDev(){
  daysTime=$(date -d "3 days ago" +%Y-%m-%d)
  devPath="/data/logs/java_service_dev/"
  dirArry=("api-service" "back-service" "game-service" "gp-payment-service" "merchant-service" "pay-service" "push-service" "task-service")

  for dir in "${dirArry[@]}"; do
    cd "${devPath}${dir}" && rm -rf $(ls "${devPath}${dir}/" | grep "$daysTime")
    if [ "${dir}" == "task-service" ]; then
      rm -rf "${devPath}${dir}/$daysTime"
    fi
  done

  time=$(date "+%Y-%m-%d %H:%M:%S")
  project_env="综合包网项目开发环境"
  days="3"

  # 调用 runSendMessage 函数
  runSendMessage "${time}" "${project_env}" "${days}"
}

deleteTest(){
  daysTime=$(date -d "3 days ago" +%Y-%m-%d)
  devPath="/data/logs/java_service_test/"
  dirArry=("api-service" "back-service" "game-service" "gp-payment-service" "merchant-service" "pay-service" "push-service" "task-service")

  for dir in "${dirArry[@]}"; do
    cd "${devPath}${dir}" && rm -rf $(ls "${devPath}${dir}/" | grep "$daysTime")
    if [ "${dir}" == "task-service" ]; then
      rm -rf "${devPath}${dir}/$daysTime"
    fi
  done

  time=$(date "+%Y-%m-%d %H:%M:%S")
  project_env="综合包网项目测试环境"
  days="3"

  # 调用 runSendMessage 函数
  runSendMessage "${time}" "${project_env}" "${days}"
}

# 调用 deleteDev 和 deleteTest 函数
deleteDev
deleteTest
