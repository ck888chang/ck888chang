#!/bin/bash

###[root@goplay-test-main shell]# cat deleteLog_3Days.sh |more
###/data/aniki/shell

echo "test.."

runSendMessage(){

curl -X POST \
     -H 'Content-Type: application/json' \
     -d '{"chat_id": "-4093063436", "text":"执行时间: '"${time}"' UTC  \n执行环境: '"${project_env}"' \n执行任务: 清理'"${project_env}"''"${days}"'天前的程序日志数据 \
n执行状态：完成", "disable_notification": true}' \
     https://api.telegram.org/bot6818519410:AAFgPkDW9PIGVfHJY5cgFornHndqExYu6do/sendMessage
}


deleteDev(){
daysTime=`date -d "3 days ago" +%Y-%m-%d`
devPath="/data/logs/java_service_dev/"
dirArry=(api-service  back-service  game-service  gp-payment-service  merchant-service  pay-service  push-service  task-service)
for (( i=0; i<${#dirArry[@]}; i++ )) do
  #echo $devPath${dirArry[i]}
  cd $devPath${dirArry[i]} && rm -rf $(ls $devPath${dirArry[i]}/| grep $daysTime)
  if [ ${dirArry[i]} == "task-service" ];then
    rm -rf  $devPath${dirArry[i]}/$daysTime
  fi
done


time=`date "+%Y-%m-%d %H:%M:%S"`
project_env="综合包网项目开发环境"
days="3"


curl -X POST \
     -H 'Content-Type: application/json' \
     -d '{"chat_id": "-4093063436", "text":"执行时间: '"${time}"' UTC  \n执行环境: '"${project_env}"' \n执行任务: 清理'"${project_env}"''"${daysTime}"'的Java程序日志数
据 \n执行状态：完成", "disable_notification": true}' \
     https://api.telegram.org/bot6818519410:AAFgPkDW9PIGVfHJY5cgFornHndqExYu6do/sendMessage

}

deleteTest(){
daysTime=`date -d "3 days ago" +%Y-%m-%d`
devPath="/data/logs/java_service_test/"
dirArry=(api-service  back-service  game-service  gp-payment-service  merchant-service  pay-service  push-service  task-service)
for (( i=0; i<${#dirArry[@]}; i++ )) do
  #echo $devPath${dirArry[i]}
  cd $devPath${dirArry[i]} && rm -rf $(ls $devPath${dirArry[i]}/| grep $daysTime)

  if [ ${dirArry[i]} == "task-service" ];then
    rm -rf  $devPath${dirArry[i]}/$daysTime
  fi

done
time=`date "+%Y-%m-%d %H:%M:%S"`
project_env="综合包网项目测试环境"
days="3"


curl -X POST \
     -H 'Content-Type: application/json' \
     -d '{"chat_id": "-4093063436", "text":"执行时间: '"${time}"' UTC  \n执行环境: '"${project_env}"' \n执行任务: 清理'"${project_env}"''"${daysTime}"'的Java程序日志数
据 \n执行状态：完成", "disable_notification": true}' \
     https://api.telegram.org/bot6818519410:AAFgPkDW9PIGVfHJY5cgFornHndqExYu6do/sendMessage

}

deleteDev
deleteTest