#!/bin/bash
#####
##### 本程式參考kk安裝k8s時相關優化參數，以及參考Aniki程式邏輯，2024年1月17日CK匯總編修
#####
kernelSet(){
    #优化内核参数
    marker="# Marker for optimization parameters"

    if ! grep -q "$marker" /etc/sysctl.conf; then
        cat >> /etc/sysctl.conf << EOF
$marker
# 防止 IP 欺騙攻擊，啟用反向路徑過濾
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.all.rp_filter = 1

# 取消註解下一行以啟用 TCP/IP SYN cookies（可能影響 IPv6 TCP 連線）
# 參見 http://lwn.net/Articles/277146/
# net.ipv4.tcp_syncookies=1

# 啟用 IPv4 封包轉發
net.ipv4.ip_forward = 1

# Magic system request Key
# 0=停用，1=啟用所有，>1 sysrq 函數的位掩碼
# 詳見 https://www.kernel.org/doc/html/latest/admin-guide/sysrq.html
#kernel.sysrq=438

# 在橋接環境中啟用 arptables、ip6tables 和 iptables 的 netfilter 呼叫
net.bridge.bridge-nf-call-arptables = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1

# 保留本機端口給應用程序（30000-32767）
net.ipv4.ip_local_reserved_ports = 30000-32767

# 設置進程的最大內存映射區域數量
vm.max_map_count = 262144

# 設置內核對交換數據到交換區的傾向（0 為保守，100 為積極）
vm.swappiness = 0

# 增加 inotify 實例的最大數量
fs.inotify.max_user_instances = 524288

# 設置最大 PID 值
kernel.pid_max = 65535

# 設置監聽隊列中的最大未完成連接數
net.core.somaxconn = 32768

# 設置最大套接字發送緩衝區大小
net.core.wmem_max = 33554432

# 設置最大套接字接收緩衝區大小
net.core.rmem_max = 33554432

# 設置網絡設備的傳輸隊列的最大長度
net.core.netdev_max_backlog = 65535

# 設置套接字最大選項記憶體大小
net.core.optmem_max = 20480

# 設置最大 TCP TIME-WAIT 桶數量
net.ipv4.tcp_max_tw_buckets = 1048576

# 設置閒置 TCP 連接上發送 keepalive 封包的時間
net.ipv4.tcp_keepalive_time = 1200

# 設置在將連接視為死亡之前進行的 keepalive 探測次數
net.ipv4.tcp_keepalive_probes = 3

# 設置 keepalive 探測之間的時間間隔
net.ipv4.tcp_keepalive_intvl = 30

# 設置 TCP 連接的重試次數
net.ipv4.tcp_retries1 = 5
net.ipv4.tcp_retries2 = 15

# 設置強制關閉 TCP 連接之前的時間
net.ipv4.tcp_fin_timeout = 30

# 設置臨時端口的本地範圍
net.ipv4.ip_local_port_range = 10000 65000

# 設置 TCP 緩衝區的記憶體閾值
net.ipv4.tcp_mem = 2304000 3072000 4608000
net.ipv4.tcp_wmem = 8192 436600 4194304
net.ipv4.tcp_rmem = 32768 436600 4194304

# 啟用或禁用 TIME-WAIT 套接字的重用
net.ipv4.tcp_tw_reuse = 0

# 設置 SYN 隊列中的最大未完成連接數
net.ipv4.tcp_max_syn_backlog = 1048576

# 設置 SYN 封包的重試次數
net.ipv4.tcp_syn_retries = 3

# 設置 SYN-ACK 封包的重試次數
net.ipv4.tcp_synack_retries = 0

# 啟用 TCP SYN cookies 以防止 SYN 洪水攻擊
net.ipv4.tcp_syncookies = 1

# 設置最大文件句柄數量
fs.file-max = 98000

# 設置最大線程數量
kernel.threads-max = 64000

# 設置 ARP 表條目垃圾回收的閾值
net.ipv4.neigh.default.gc_thresh1 = 512
net.ipv4.neigh.default.gc_thresh2 = 2048
net.ipv4.neigh.default.gc_thresh3 = 4096

# 設置孤兒套接字的最大數量
net.ipv4.tcp_max_orphans = 65535

# 設置 UDP 接收緩衝區的最小大小
net.ipv4.udp_rmem_min = 131072

# 設置 UDP 發送緩衝區的最小大小
net.ipv4.udp_wmem_min = 131072

# 啟用 ARP 接受和忽略設定
net.ipv4.conf.all.arp_accept = 1
net.ipv4.conf.default.arp_accept = 1
net.ipv4.conf.all.arp_ignore = 1
net.ipv4.conf.default.arp_ignore = 1

# 設置內核的超額內存處理模式（0 為啟發式，1 為總是）
vm.overcommit_memory = 0

# 設置最大 inotify 監聽數量
fs.inotify.max_user_watches = 524288

# 設置管道容量的最大大小
fs.pipe-max-size = 4194304

# 設置異步 I/O 請求的最大數量
fs.aio-max-nr = 262144

# 設置內核看門狗的閾值
kernel.watchdog_thresh = 5

# 設置掛起任務的超時時間
kernel.hung_task_timeout_secs = 5
EOF
        echo -e "\033[31m 主机 优化Kernel参数完毕 \033[0m"
        return 0
    else
        echo -e "\033[31m Kernel parameters already optimized. Skipping... \033[0m"
        return 1
    fi
}
#6.句柄数
fileLimits(){
    marker="# Marker for file limits"

    if ! grep -q "$marker" /etc/security/limits.conf; then
        cat >> /etc/security/limits.conf << EOF
$marker
# 設定用戶打開的檔案數量限制
# soft：指定軟限制，表示實際限制值，但用戶可以動態調整，不能超過硬限制。
# hard：指定硬限制，表示用戶不能通過 ulimit 命令將限制值調整為超過硬限制的值。
# 在這裡，將單一用戶可打開的檔案數量限制設為 1048576。
* soft nofile 1048576
* hard nofile 1048576

# nproc 表示單一用戶可創建的進程數量。將單一用戶可創建的進程數量限制設為 65536。
* soft nproc 65536
* hard nproc 65536

# 設定用戶可鎖定的記憶體量限制；memlock 表示單一用戶可鎖定的記憶體量。
# unlimited 表示單一用戶無限制，用戶可以鎖定所有可用的記憶體。
* soft memlock unlimited
* hard memlock unlimited
# End of file
EOF
        echo -e "\033[31m 主机 优化句柄数 参数完毕  \033[0m"
        return 0
    else
        echo -e "\033[31m File limits already configured. Skipping... \033[0m"
        return 1
    fi
}


mainprocess() {
    ###需要判断系统类型
    VersionFile="/etc/os-release"
    if [ ! -f "$VersionFile" ]; then
        VersionFile="/etc/issue"
    fi

    echo -e "\033[31m #################\033[0m"
    ##初始化脚本
    echo -e "\033[31m 判断系统类型\033[0m"

    # 檢查系統是否是 Debian 並且版本是 12
    SYSTEM_TYPE=$(awk -F "=" '/^ID=/ { gsub(/"/,""); print $2 }' "$VersionFile")
    SYSTEM_VERSION=$(awk -F "=" '/^VERSION_ID=/ { gsub(/"/,""); print $2 }' "$VersionFile")

    if [ "$SYSTEM_TYPE" == "debian" ] && [ "$SYSTEM_VERSION" == "12" ]; then
        echo -e "\033[31m The System OS: $SYSTEM_TYPE, Version: $SYSTEM_VERSION \033[0m"
        kernelSet
        fileLimits
        if [ $? -eq 0 ]; then
            echo -e "\033[31m Initialization for Debian 12 completed! \033[0m"
        else
            echo -e "\033[31m 程式已設定過，本次執行略過 \033[0m"
        fi
    else
        echo -e "\033[31m System OS or version does not match the requirements. Exiting... \033[0m"
        exit 1
    fi
}

#1.检查系统
if [ "$EUID" -ne 0 ]; then
    echo -e  "\033[31m 必须是root用户才能执行此脚本 \033[0m" 2>&1
    exit 1
else
    mainprocess
fi

