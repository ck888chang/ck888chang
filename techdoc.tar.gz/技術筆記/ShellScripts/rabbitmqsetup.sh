#!/bin/bash

cat <<EOL > cluster_setup_rabbitmq.sh
#!/bin/bash
rabbitmqctl stop_app
rabbitmqctl join_cluster --ram rabbit@node1
rabbitmqctl start_app
EOL


# 檢查檔案是否存在
if [ -e "cluster_setup_rabbitmq.sh" ]; then
    # 如果檔案存在，執行 chmod 755
    chmod 755 cluster_setup_rabbitmq.sh
    echo "設定檔案權限完成。"
else
    # 如果檔案不存在，顯示錯誤訊息
    echo "錯誤：檔案 cluster_setup_rabbitmq.sh 不存在。"
    exit 1
fi

if docker ps | grep -e 15671 -e 15692 -e 4369 -e rabbit; then
    echo "rabbit容量已在執行，或port端口已在使用中"
    exit 1  # 強制退出，並返回退出碼 1
fi

# 檢查是否存在 rabbitmq:3.12.10-management 映像
if docker images | grep -E '^rabbitmq[[:space:]]+3\.12\.10-management'; then
    echo "rabbitmq:3.12.10-management 映像已存在，不需要重新拉取。"
else
    echo "rabbitmq:3.12.10-management 映像不存在，正在拉取..."
    docker pull rabbitmq:3.12.10-management
    if [ $? -ne 0 ]; then
    echo "錯誤：拉取 rabbitmq 映像失敗。"
    exit 1
    fi
fi

# 建立 Docker 網路
docker network create rabbitmq-net

# 啟動 Docker 容器 1
echo "啟動 Docker 容器 1"
docker run -d --restart=always \
   --name rabbitmq1 \
   --hostname node1 \
   --network rabbitmq-net \
   --log-opt max-size=10m \
   --log-opt max-file=3 \
   -p "4369:4369" \
   -p "5671:5671" \
   -p "5672:5672" \
   -p "15671:15671" \
   -p "15672:15672" \
   -p "25672:25672"  \
   -e RABBITMQ_DEFAULT_USER=admin \
   -e RABBITMQ_DEFAULT_PASS=I8fYdZjGG0U31XhV \
   -e RABBITMQ_ERLANG_COOKIE=mysecretcookie \
   -e RABBITMQ_NODENAME=rabbit rabbitmq:3.12.10-management


echo "啟動 Docker 容器 2"
docker run -d --restart=always \
    --name rabbitmq2 \
    --hostname node2 \
    --network rabbitmq-net \
    --log-opt max-size=10m \
    --log-opt max-file=3 \
    -p "5673:5672" \
    -p "15673:15672" \
    -p "25673:25672" \
    -e RABBITMQ_DEFAULT_USER=admin \
    -e RABBITMQ_DEFAULT_PASS=I8fYdZjGG0U31XhV \
    -e RABBITMQ_ERLANG_COOKIE=mysecretcookie \
    -e RABBITMQ_NODENAME=rabbit rabbitmq:3.12.10-management



# 啟動 Docker 容器 3
echo "啟動 Docker 容器 3"
docker run -d \
   --restart=always \
   --name rabbitmq3 \
   --hostname node3 \
   --network rabbitmq-net \
   --log-opt max-size=10m \
   --log-opt max-file=3 \
   -p "5674:5672" \
   -p "15674:15672" \
   -p "25674:25672" \
   -e RABBITMQ_DEFAULT_USER=admin \
   -e RABBITMQ_DEFAULT_PASS=I8fYdZjGG0U31XhV \
   -e RABBITMQ_ERLANG_COOKIE=mysecretcookie \
   -e RABBITMQ_NODENAME=rabbit rabbitmq:3.12.10-management


echo "所有 Docker 容器已建立"

# 等待 RabbitMQ 服務啟動完成
echo "等待 RabbitMQ 服務啟動..."
sleep 30

# 建立 RabbitMQ Cluster
echo "Starting to build rabbitmq cluster."

# 在 rabbitmq2 容器内執行脚本
docker cp cluster_setup_rabbitmq.sh rabbitmq2:/cluster_setup_rabbitmq.sh
docker exec rabbitmq2 /bin/bash -c '/cluster_setup_rabbitmq.sh'

# 在 rabbitmq3 容器内執行脚本
docker cp cluster_setup_rabbitmq.sh rabbitmq3:/cluster_setup_rabbitmq.sh
docker exec rabbitmq3 /bin/bash -c '/cluster_setup_rabbitmq.sh'

echo "完成 RabbitMQ Cluster"

# check cluster status
echo "Check cluster status:"
docker exec rabbitmq1 /bin/bash -c "rabbitmqctl cluster_status"
docker exec rabbitmq2 /bin/bash -c "rabbitmqctl cluster_status"
docker exec rabbitmq3 /bin/bash -c "rabbitmqctl cluster_status"

#add new vhost (dev/test)
docker exec rabbitmq1 /bin/bash -c "rabbitmqctl add_vhost dev"
docker exec rabbitmq1 /bin/bash -c "rabbitmqctl add_vhost test"

docker exec rabbitmq1 /bin/bash -c "rabbitmqctl set_policy ha-all \"^\" '{\"ha-mode\":\"all\"}'"
docker exec rabbitmq1 /bin/bash -c "rabbitmqctl set_policy --vhost dev ha-all \"^\" '{\"ha-mode\":\"all\"}'"
docker exec rabbitmq1 /bin/bash -c "rabbitmqctl set_policy --vhost test ha-all \"^\" '{\"ha-mode\":\"all\"}'"


# 等待使用者按下任意鍵以關閉視窗

