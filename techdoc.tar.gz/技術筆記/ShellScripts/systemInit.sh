#!/bin/bash
###
### from aniki kubesphere http://13.228.160.95:30880/
###

 echo -e  "\033[31m 初始化脚本"

#1.服務檢查
disableServer(){
    Serverarry=(rpcbind.socket postfix firewalld rpcbind cups)
    #遍历数组ServerArry
    for (( i=0; i<${#Serverarry[@]};    i++  )) do

        systemctl stop ${Serverarry[i]}
        echo -e "\033[31m 停止 ${Serverarry[i]} 完毕 \033[0m"
        systemctl disable ${Serverarry[i]}
        echo -e "\033[31m 关闭 ${Serverarry[i]} 开机启动完毕 \033[0m"
    done
}


#2.确认网络信息

networkCheck(){
    ##nameserver 100.100.2.136 nameserver 100.100.2.138
    #确认是否配置dns
    AliDNS=false
    GooDNS=false
    ##nameserver 100.100.2.136 nameserver 100.100.2.138
    #确认是否配置dns

    AlibabaDNS=(100.100.2.136 100.100.2.138)
    setDNS=()
    #查看主机配置的dns并组合数据成数组
    num=` cat /etc/resolv.conf | grep nameserver | awk -F " " '{print $2}' | wc -l`
    for (( i=0; i<$num;i++ )) do
        xx=`expr $i + 1`
        setDNS[$i]=`cat /etc/resolv.conf | grep nameserver | awk -F " " '{print $2}' |sed -n  ''${xx}'p' `
    done
 #遍历数组AlibabaDNS,并和获取到的主机的dns服务器地址比较
    for (( i=0; i<${#AlibabaDNS[@]};    i++  )) do
        if test -z "$(nl /etc/resolv.conf  | sed -n '/${AlibabaDNS[i]}/p')"; then
            echo -e  "\033[31m DNS$i Server 确认中... ${AlibabaDNS[i]}  \033[0m"
                for (( k=0; k<${#setDNS[@]};    k++  ))  do
                        if [  ${AlibabaDNS[$i]} == ${setDNS[$k]} ] ;then
                        AliDNS=true
                        continue
                        fi
                done
        fi

    done
    #判断条件并跟进条件设置DNS
    if test -n "$(nl /etc/resolv.conf  | sed -n '/8.8.8.8/p')"; then
        GooDNS=true
    fi
    if  $AliDNS ; then
        echo -e  "\033[31m 阿里云的主机,暂不设置GOOGLE DNS  \033[0m"
    elif $GooDNS ; then
        echo -e  "\033[31m 已经设置google的dns服务器 \033[0m"
    elif ! $AliDNS && ! $GooDNS  ; then
        echo -e  "\033[31m 没有设置google的dns服务器 \033[0m"
        sed 's/nameserver 8.8.8.8/nameserver 8.8.8.4/g' /etc/resolv.conf  -i
        sed '$anameserver 8.8.8.8'  /etc/resolv.conf  -i
        echo -e  "\033[32m 设置google的dns服务器 完毕! \033[0m"
    fi

    #确认网络ip并设置时区
    countryCode=(VN SG HK US KH)
    #array=(`curl  -s ipinfo.io | grep  country | awk -F  '"' '{ print $4 }' `)
    array=(`curl -s  api.myip.la/en | awk -F " " '{print $2}' `)
    #使用map
declare -A countryCodeMap

    countryCodeMap[VN]="Asia/Ho_Chi_Minh"
    countryCodeMap[SG]="Asia/Singapore"
    countryCodeMap[HK]="Asia/Hong_Kong"
    countryCodeMap[US]="America/New_York"
    countryCodeMap[KH]="Asia/Phnom_Penh"

    echo ${!countryCodeMap[@]}
    echo ${countryCodeMap[@]}
    for key in ${!countryCodeMap[@]};do
        echo "key:"$key
        echo "value:"${countryCodeMap[$key]}
         if  [ $key == ${array[0]} ]; then
             echo -e  "\033[31m $key 主机,设置$key 时间\033[0m"
            #/usr/share/zoneinfo/Asia/Ho_Chi_Minh

            timezoneFile=(`md5sum /usr/share/zoneinfo/${countryCodeMap[$key]} | awk -F " " '{print $1}'`)
            localZoneFile=(`md5sum /etc/localtime | awk -F " " '{print $1}'`)
            echo "$timezoneFile"
            echo "$localZoneFile"
                if [[  $timezoneFile != $localZoneFile ]]; then
                    timedatectl  set-timezone ${countryCodeMap[$key]}
                    ln -svf  /usr/share/zoneinfo/${countryCodeMap[$key]} /etc/localtime
                else
                    echo -e "\033[32m 主机时区是${countryCodeMap[$key]} 目前区域所在时区,无需调整！\033[0m"
                fi
            echo   "1 1 */1 * * ntpdate asia.pool.ntp.org" >> /var/spool/cron/root &&  chmod 600 /var/spool/cron/root
            break
        elif [ ${#countryCodeMap[@]} -eq  4 ]; then
            echo -e  "\033[31m 该主机 不适合此脚本的 时区设置 \033[0m"
            break
        fi
    done
     echo -e  "\033[31m 主机设置时区完毕 \033[0m"
}



#3.Slinux 修改

disableSelinux(){
    if [ -f /etc/selinux/config ];then
    sed -i 's/enforcing/disabled/' /etc/selinux/config
    fi
     echo -e  "\033[31m 主机关闭 Selinux 设置完毕 \033[0m"
}

#4.安装更新

yumUpdate(){
        # 添加四个源
    for url in urls https://download1.rpmfusion.org/free/el/rpmfusion-free-release-7.noarch.rpm \
    https://download1.rpmfusion.org/nonfree/el/rpmfusion-nonfree-release-7.noarch.rpm \
    http://rpms.famillecollet.com/enterprise/remi-release-7.rpm \
    http://repo.webtatic.com/yum/el7/webtatic-release.rpm; \
    do yum  -y localinstall --nogpgcheck $url &&  echo -e  "\033[32m 添加YUM源--->$url  中.........\033[0m"; done

    # 添加www.elrepo.org 源
    rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
        rpm -Uvh http://www.elrepo.org/elrepo-release-7.0-3.el7.elrepo.noarch.rpm
        echo -e  "\033[32m 添加YUM源--->https://www.elrepo.org 中.........\033[0m"
        # 更新系统
        yum clean all && yum update -y
    # 安装软件
    for packages in patch gcc gcc-c++ iptables-services cmake make autoconf libtool-ltdl-devel gd-devel freetype-devel libxml2-devel libjpeg-devel libpng-devel openssl-devel curl-devel bison patch unzip libmcr
ypt-devel libmhash-devel ncurses-devel mlocate flex sysstat libaio-devel ntp openldap-devel openssl-devel libcurl-devel unzip perl-ExtUtils-CBuilder perl-ExtUtils-MakeMaker iotop bzip2* rdate vim tmux util-lin
ux-ng pcre pcre-devel libevent-devel git tree wget pcre pcre-devel libevent-devel;
    do yum -y -q install $packages &&  echo -e  "\033[32m安装$packages 中.........\033[0m"; done
     echo -e  "\033[31m 主机安装常用 软件包完毕\033[0m "
}

#5.kernel

kernelSet(){

#优化内核参数
cat >> /etc/sysctl.conf << EOF
net.core.somaxconn = 65535
net.core.wmem_max = 16777216
net.core.rmem_max = 1024123000
net.core.netdev_max_backlog = 1000
net.core.optmem_max = 20480
net.ipv4.tcp_max_tw_buckets = 262144
net.ipv4.tcp_keepalive_time = 1200
net.ipv4.tcp_keepalive_probes = 3
net.ipv4.tcp_keepalive_intvl = 30
net.ipv4.tcp_retries1 = 5
net.ipv4.tcp_retries2 = 5
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_tw_recycle = 1
net.ipv4.ip_local_port_range = 10000 65000
net.ipv4.tcp_mem = 2304000 3072000 4608000
net.ipv4.tcp_wmem = 8192 436600 4194304
net.ipv4.tcp_rmem = 32768 436600 4194304
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_max_syn_backlog = 200000
net.ipv4.tcp_syn_retries = 3
net.ipv4.tcp_synack_retries = 0
net.ipv4.tcp_syncookies = 1
net.core.netdev_max_backlog = 165536

EOF

 echo -e  "\033[31m 主机 优化Kernel参数完毕 \033[0m "
}
#6.句柄数
fileLimits(){
cat >> /etc/security/limits.conf <<EOF
* soft nofile 1024000
* hard nofile 1024000
hive   - nofile 1024000
hive   - nproc  1024000
# End of file
EOF
 echo -e  "\033[31m 主机 优化句柄数 参数完毕  \033[0m"
}

#7.历史记录

commedHistory(){
#保留历史记录
cat >> /etc/bashrc <<EOF
export HISTTIMEFORMAT="%Y-%m-%d %H:%M:%S "
export HISTFILESIZE=1000000
export HISTSIZE=2000
EOF
source /etc/bashrc

cat >> /etc/profile <<EOF
USER_IP=\`who -u am i 2>/dev/null| awk '{print \$NF}'|sed -e 's/[()]//g'\`
HISTFILESIZE=4000
HISTSIZE=4000
HISTTIMEFORMAT="%F %T \${USER_IP} \`whoami\` "
export HISTTIMEFORMAT
EOF
 echo -e  "\033[31m 主机 优化历史命令记录 参数完毕 \033[0m "
}

#9.添加用戶
addUser(){

#添加jumpserver用户
/usr/sbin/groupadd wheel
/usr/sbin/useradd jumpserver -g wheel
#添加key信息
mkdir -p  /home/jumpserver/.ssh
touch /home/jumpserver/.ssh/authorized_keys
cat >> /home/jumpserver/.ssh/authorized_keys <<EOF
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCb+UK2e+dpJXr+oC2DvOrhibYnHcDa1wlE6f/rkmBAqgI8A4tnsdZfDQ3zBpwMqZnRF26ioe8P1GlOeSR155mgHed81XFdsrYDGzvQYpKuU1D0jZkRHrVwin4o3YNnISFtEcuRgEcR8ZkqZeXcs/UPGMkc+nqMmB80e1Ummb3K1
BVE8neKPLevCEkOSMeTWnt1NaKCVubzG/Ht4wtlYd7LQzSaj1GT/8QTZY5dwebad/X3y/dM4+ey9RU6ilAPSQPu7qRG9d7520AwtjEVoQJmotIATIZv9VM31tLFrtriyYKcl29DloEgwRoeuvxNCS9X71HGKSqXbpRvDl4d8Lgx jumpserver@instance-1
EOF
touch /home/jumpserver/.ssh/id_rsa
cat >> /home/jumpserver/.ssh/id_rsa <<EOF
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAm/lCtnvnaSV6/qAtg7zq4Ym2Jx3A2tcJROn/65JgQKoCPAOL
Z7HWXw0N8wacDKmZ0RduoqHvD9RpTnkkdeeZoB3nfNVxXbK2Axs70GKSrlNQ9I2Z
ER61cIp+KN2DZyEhbRHLkYBHEfGZKmXl3LP1DxjJHPp6jJgfNHtVJpm9ytQVRPJ3
ijy3rwhJDkjHk1p7dTWiglbm8xvx7eMLZWHey0M0mo9Rk//EE2WOXcHm2nf198v3
TOPnsvUVOopQD0kD7u6kRvXe+dtAMLYxFaECZqLSAEyGb/VTN9bSxa7a4smCnJdv
Q5aBIMEaHrr8TQkvV+9Rxikql26Ubw5eHfC4MQIDAQABAoIBAG7r6hy6qwykwf54
zUWFwYhZljflOfSnvojK3NycAWWbQfGKF8bLuwdn0kbFqY57ws7nGiAAh3G7fpR3
JI3RAfjTq3+kj3WyFSzKXlRI9cWRrN3uITACpcf+RdAsEDn0XsAhSqMUFfbV2TZE
tx6owBtXZhb8rtBzkqWRHDJSXZ3y71eeuc6oi/NDUe3H2D/vq4OltoRGGvNC/sJn
B4LVE3YebH9xGT8RUlS41QOomZOuUC31M022jwV/HUX1mbXKV3MK7XlRocn4ys1j
hG7Fqgpgp/5TIzEeBaymK1gsIr6NZzDQP4JA74GZKSF/3L3Z8TsQNkzF1/g2PkPk
F3Pu2k0CgYEAy0dFVnSiioN57U8VEqFAUcjmnG3ywgz6IXny5TTDonOSN25BCjhO
sK49PvKSOYzo/No5aY/mrikHMuX9wbmaXgshxHe2amso1oGvzeRzfzJpGEiJ5dIn
LCuU/Z5bbqjNrgwwYJ7yfGAGB9IuG1qJtsdZaz9Ngp49OMrILjSEiZMCgYEAxG0t
sJzsxHPASrPOSIPJWH3OUSjydEiRVrRFKo6xycpaVm+v+WpSPGi/sm7+rMpkfNA6
JvEv+T75fzxCx4R2rPqWbAKkkKTZ957aQoI7y27qw+xlfV49/cWSbXcgkOMBYoid
8FkRtbhtdIFq/iBR8PL2qf81Z0TG9gZ7ezYrwasCgYB5FeUpkKRZmeOBBkBpLoBf
tyoXOC8IhC5izn9vJLT8CZepSRWY/t1wxPlai6eqfFM0etEEHmGskGfnW7SCNwrK
xhrBKwYP8fELhYixPknGFMMhYeQyb7JBz1wajr+r9QU/jacrhsKub4xoEDzCsnWh
2LFc/wIusg+JytDfJQ1l3QKBgDQwohQsDcjAzJXMooGn6maFvrzXuVvmMB+udDYz
hc+M4WXX9RS7CDCe0FhTn30/pWV4WgsgyFNcRSRmWYPzkSiyyCbYqOr5siRV474K
JmMODHiUJf8ifCwiQ56sKU310tdgXz6OG+OBpitve4McCUmQ9LMEaScQIiEaZdK9
+PBTAoGBALzRe3duP5wIIx0GvsD/MSKpt6zpsmIe6EgK63VUBCguqEmgEajvvbQk
EnTD4UbDGixRHKbr8pEQUH8h8JkaCHutvaPn3dPuL7nF4CzAmFCyf3jwDqgOKOyu
l4q7xUOtwdiXnTvnATym4SOqIavpbgjcOkmmj5ndzSR98njmCNAO
-----END RSA PRIVATE KEY-----
EOF
touch /home/jumpserver/.ssh/id_rsa.pub
cat >> /home/jumpserver/.ssh/id_rsa.pub <<EOF
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCb+UK2e+dpJXr+oC2DvOrhibYnHcDa1wlE6f/rkmBAqgI8A4tnsdZfDQ3zBpwMqZnRF26ioe8P1GlOeSR155mgHed81XFdsrYDGzvQYpKuU1D0jZkRHrVwin4o3YNnISFtEcuRgEcR8ZkqZeXcs/UPGMkc+nqMmB80e1Ummb3K1
BVE8neKPLevCEkOSMeTWnt1NaKCVubzG/Ht4wtlYd7LQzSaj1GT/8QTZY5dwebad/X3y/dM4+ey9RU6ilAPSQPu7qRG9d7520AwtjEVoQJmotIATIZv9VM31tLFrtriyYKcl29DloEgwRoeuvxNCS9X71HGKSqXbpRvDl4d8Lgx jumpserver@instance-1
EOF


#添加jumpserver-user用户
/usr/sbin/useradd jumpserver-user
#添加key信息
mkdir -p /home/jumpserver-user/.ssh
touch /home/jumpserver-user/.ssh/authorized_keys
cat >> /home/jumpserver-user/.ssh/authorized_keys <<EOF
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCs6PlbbbThxKTzP3ZDLvZJUHW5FtYhbCbBORXP7RXjN00IaTy+pbiwsJWGaH25COJSa+t1JbEBZkFuPnMSrl0Rgvu0SPzF5aOoiBX/LjAj5lUEPe5/uu6Cnv+ViQVFIDAfbrKYjdbMgq18LbmOVcMSM8hUT/Ak1s8BUbhfLcGXg
3cqs+MLbcz7ZfDVP3pZWu1YIvsSz43B/B6dxKbq041dGBFNQ9HG0NO7U6GaDmAH9eakiSQwoblzLW660+NlRvlL8r66j7vkUgrh9BUkReHcPl6TeSKA0o9cZkDdJOQvXy+h/UOPaFnjVb7OE9viQ4dNDfMlLAfCxUZhWxN4SuH3 jumpserver-user@instance-1
EOF
touch /home/jumpserver-user/.ssh/id_rsa
cat >> /home/jumpserver-user/.ssh/id_rsa <<EOF
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEArOj5W2204cSk8z92Qy72SVB1uRbWIWwmwTkVz+0V4zdNCGk8
vqW4sLCVhmh9uQjiUmvrdSWxAWZBbj5zEq5dEYL7tEj8xeWjqIgV/y4wI+ZVBD3u
f7rugp7/lYkFRSAwH26ymI3WzIKtfC25jlXDEjPIVE/wJNbPAVG4Xy3Bl4N3KrPj
C23M+2Xw1T96WVrtWCL7Es+NwfwencSm6tONXRgRTUPRxtDTu1Ohmg5gB/XmpIkk
MKG5cy1uutPjZUb5S/K+uo+75FIK4fQVJEXh3D5ek3kigNKPXGZA3STkL18vof1D
j2hZ41W+zhPb4kOHTQ3zJSwHwsVGYVsTeErh9wIDAQABAoIBAAYrznJ/6NvB6+0u
j6b4LxwQvhLcCMpqlLuCsQ+Zs5VHbP1m3B8lxQCxXLTOV+ZZtdIhPecRcE7PenhX
zD2XcYTletxFWpgpiPzD1p0j5d3yI4iiOTff0RFiYVbR7Bk6e90zUzZ0oXztEQoE
i8HTt8GXjYfMzpJSBFNUulLTTDx/Cp02FKlRG9mMwOofyPiZ9CGuPO0fojLnS34N
sTXRrW0T9dL563RWkbCG4DlYrpqRLpDP3IvYyV5U1gPrX2Kb4mQJcmQ4uBLDHzKb
+vM/mTbbVULsbmC/nFyJ+oMQ+NFEnqQNZwIVXK6oAM9BK5U00XAy0q/HzMqt61Hz
mm5gReECgYEA4T6ph/GFQl36rwFYI1A6dC+i1565uS5SDA9NCX8tXSHoqeQtiYKe
X1kDj69tNE51ynCqza6uvgpWpKHkY4S39j3l8B4Y12fgq4zFT5naaQZZT2nl5ygm
ak5+2eYWNm4qL2svs5XcR9y+wZokn56fe3Fb1EwqU5O4B04ZqOxEUnECgYEAxIT5
L7dSCBSK1kDWeXg5rPelZN00OMXY34PwotZDqG6xcIBtdzEKgL2/9B9I2fB3jwPG
HFAdGJ6OS+4ZRoc4HCCQiUHUOEVecTPIDDgp+J8cUVnEH07SxJ0if7INRMRxUSHk
wkSWmmWEHOorHxwWBWYemLUN5kI8ozwWlHfPXucCgYBrc5ksYOtRXcPY+KszLXK1
OoRUmEPBM3ewiRwXC7R4WVTEtzWCA+3JTo2EXguaiFNo35abyFlUD1qF7zUkxIt9
zMmEYtc26zcin2UBNEQdFgpE+B/UxjKNRCT/jePK04MMW/XFlhgfsA7QDNirzOAH
42wLOsp2VGHWGkvjadKuAQKBgBEds8ZgJRjnESCQDR4PRpa2CwW57m5zbOwqxa6p
EsN8wJ+Xz/DtqIiF/k3425N/yin+niahI6edR699UV4/MLfibjRGM4GjKRKa+/V0
ftNUqFa9hsNjTiApv3N3wogWw/fZB9+TsbpI1TTfgFn5TEG0Hz4VptxDMJzXAvBz
bvBJAoGBAJTZRrGAreNLldtN6kutbayBqW83+RRkKznrbZ7r4mHrDuUQjkjbKZUa
cCZ7Vy+HaR+IA1p+mlAbLh2BnvWFl4DY3vI1YJfua7pnRXjR1h64MSqkz1jpH2Su
YjXERk/VolTJle4iKysbEEz4pQ2OL7AUBA41OYIaDfp6PQEP5Eje
-----END RSA PRIVATE KEY-----
EOF
touch /home/jumpserver-user/.ssh/id_rsa.pub
cat /home/jumpserver-user/.ssh/id_rsa.pub <<EOF
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCs6PlbbbThxKTzP3ZDLvZJUHW5FtYhbCbBORXP7RXjN00IaTy+pbiwsJWGaH25COJSa+t1JbEBZkFuPnMSrl0Rgvu0SPzF5aOoiBX/LjAj5lUEPe5/uu6Cnv+ViQVFIDAfbrKYjdbMgq18LbmOVcMSM8hUT/Ak1s8BUbhfLcGXg
3cqs+MLbcz7ZfDVP3pZWu1YIvsSz43B/B6dxKbq041dGBFNQ9HG0NO7U6GaDmAH9eakiSQwoblzLW660+NlRvlL8r66j7vkUgrh9BUkReHcPl6TeSKA0o9cZkDdJOQvXy+h/UOPaFnjVb7OE9viQ4dNDfMlLAfCxUZhWxN4SuH3 jumpserver-user@instance-1
EOF
echo -e  "\033[31m 主机 密钥权限修改,完毕 \033[0m "

}



addUserOUT(){
#添加jumpserver用户
/usr/sbin/groupadd wheel
#添加jumpserver用户
/usr/sbin/useradd jumpserver -g wheel
#添加key信息
/usr/bin/mkdir -p /home/jumpserver/.ssh
/usr/bin/touch /home/jumpserver/.ssh/authorized_keys
/usr/bin/cat >> /home/jumpserver/.ssh/authorized_keys <<EOF
#ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCb+UK2e+dpJXr+oC2DvOrhibYnHcDa1wlE6f/rkmBAqgI8A4tnsdZfDQ3zBpwMqZnRF26ioe8P1GlOeSR155mgHed81XFdsrYDGzvQYpKuU1D0jZkRHrVwin4o3YNnISFtEcuRgEcR8ZkqZeXcs/UPGMkc+nqMmB80e1Ummb3K
1BVE8neKPLevCEkOSMeTWnt1NaKCVubzG/Ht4wtlYd7LQzSaj1GT/8QTZY5dwebad/X3y/dM4+ey9RU6ilAPSQPu7qRG9d7520AwtjEVoQJmotIATIZv9VM31tLFrtriyYKcl29DloEgwRoeuvxNCS9X71HGKSqXbpRvDl4d8Lgx jumpserver@instance-1
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDJ3Q8GKK7RiuRcT9REmgWNNOWSAHcMtT5dAGceOJspILsnmwnCd7LBK5T8kxAKv73TYkKWCjrFJZg10DIt658we6wjsFnzB8o4KQYL3Fz6kvUMUVun/XegdtBLP9Zc3uHjcE1IpTcJsLdMySFXMit03OJephtQTn0GkvAwvJH7B
TpZLM64ArX1i0bRe5L+/sVipHOE1qcoWsme0rfgZD4/3mjgtadCDqfbPxT5xf9NB2U+/mX0K32KcW2I0cV8X35idyEUMYJMjNAvuMzlBxf+3jblhZLwbb3XZOy8oflzF3eVM8n+FpH1LQUdYglHdRXtFs0JV10QRn1nZkgZguob
#jumpserver@localhost.localdomain
EOF
/usr/bin/touch /home/jumpserver/.ssh/id_rsa
/usr/bin/cat >> /home/jumpserver/.ssh/id_rsa <<EOF
-----BEGIN RSA PRIVATE KEY-----
MIIEpQIBAAKCAQEAyd0PBiiu0YrkXE/URJoFjTTlkgB3DLU+XQBnHjibKSC7J5sJ
wneywSuU/JMQCr+902JClgo6xSWYNdAyLeufMHusI7BZ8wfKOCkGC9xc+pL1DFFb
p/13oHbQSz/WXN7h43BNSKU3CbC3TMkhVzIrdNziXqYbUE59BpLwMLyR+wU6WSzO
uAK19YtG0XuS/v7FYqRzhNanKFrJntK34GQ+P95o4LWnQg6n2z8U+cX/TQdlPv5l
9Ct9inFtiNHFfF9+YnchFDGCTIzQL7jM5QcX/t425YWS8G2912TsvKH5cxd3lTPJ
/haR9S0FHWIJR3UV7RbNCVddEEZ9Z2ZIGYLqGwIDAQABAoIBAAm7tvW9EHDaGZi5
4KpOIuZkHo2jqBncw10In/A9Gn4pLd0DBL1zuBLIXy6uiJ98D1MZ8cv6QksvPN+b
YlAEhHB6BhrSbgPh5EZA9CGuRm1umJI3egvnlNUP5Ys7UMK5nHqy94cBMF4vPydc
q1bg/GduHxwhNj/xCOZAP4SaEw/fYrUB+dgED9UhkUHJreYMB3EtcmZpFneuAlsj
/or0y8/7Dc4wsuhk9vFJjbsba0VQQxi3GK6UTf5Ek8h6CBxTYkMzt5yCsfHVEaoF
GEGbmAe5E4dIZz4lxy/W3zFd7kinPSVGCBgrmy71HrMT3JiIuzMHdN4ZRTYKzYeO
poizTQECgYEA75RcIb8USr89o2Opys1VblvX5vNnKU7E0vOYjjbHWpj8RHtYfxGc
DsICO+O7PIapnRtdnyRbWrlyi/3CjH306DY6yiNF2GMleZ3zTwXq1f3/3VvTwV4S
lfgfXffe28IPecZej/YkLNzZH1oWCa9Hc6IEZHsOitxKrEmdUu6aO4sCgYEA17Lv
4Ki8hvvcWev2GeB+Ht44ff9UhjaMuad45GaWggy6I6Wlp8bRRkiCRjzVv3maq4sl
hjCfzlrVPIQbfS1x1IFM9lsFtoHJkPjri5Y2DJcjbuVoDfZnr4Sx3nc5GUT/vpOZ
Kp9NgWdfGuQkfZ46SySeaBsSwrROfAYdXZCDHbECgYEA6nU+VKgyq5PMNoHqQFYC
LSYkfBfn9Tzo0akiuspQ/hCJkFtFl9Ub7DVhCksriWgfxWhqjrt9y6OAvg9wvRzm
9/laP0eVqtYcbpBs9ADOeO1B4Ndku+/cMHfJ+qQArP+VNY80K56ueFkJAu2ec4vd
WQRNWCg1ax961HCWTfrDZVECgYEA0lFZcDdXTE78dnmLh4PLthF8B+8U3aEG6meP
izU0gC4kuWlk8wj7OYqt7AqZaJAL7kRJHGUBDVaoIM+3dgD/wvMotfXexiwa/E6a
bYrTvMcJ97GcGjEuvIeoX4Dkne0XaR3F9TdLfWfr5e6aXhoQQQC9rEjprAvfkzLr
IzYrgqECgYEAxoHFRaDB/Nv5sgk9HrEOPWIEWkITFwWQTqttylaA5qJtzklAcJc2
6yGPtdkJzmav7kk2Lx2XXrHTs73B6bSsoCU/NwW7VniqeJcn+jKrtpX9Xhr20NaH
xidQuz9DZMWevQyi80x8W6Iw4hSsOS4pb9fTyaXbe9wDoWvv5PVdlOc=
-----END RSA PRIVATE KEY-----
EOF
/usr/bin/touch /home/jumpserver/.ssh/id_rsa.pub
/usr/bin/cat >> /home/jumpserver/.ssh/id_rsa.pub <<EOF
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCb+UK2e+dpJXr+oC2DvOrhibYnHcDa1wlE6f/rkmBAqgI8A4tnsdZfDQ3zBpwMqZnRF26ioe8P1GlOeSR155mgHed81XFdsrYDGzvQYpKuU1D0jZkRHrVwin4o3YNnISFtEcuRgEcR8ZkqZeXcs/UPGMkc+nqMmB80e1Ummb3K1
BVE8neKPLevCEkOSMeTWnt1NaKCVubzG/Ht4wtlYd7LQzSaj1GT/8QTZY5dwebad/X3y/dM4+ey9RU6ilAPSQPu7qRG9d7520AwtjEVoQJmotIATIZv9VM31tLFrtriyYKcl29DloEgwRoeuvxNCS9X71HGKSqXbpRvDl4d8Lgx jumpserver@instance-1
EOF


#添加jumpserver-user用户
/usr/sbin/useradd jumpserver-user
#添加key信息
/usr/bin/mkdir -p /home/jumpserver-user/.ssh
/usr/bin/touch /home/jumpserver-user/.ssh/authorized_keys
/usr/bin/cat >> /home/jumpserver-user/.ssh/authorized_keys <<EOF
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCs6PlbbbThxKTzP3ZDLvZJUHW5FtYhbCbBORXP7RXjN00IaTy+pbiwsJWGaH25COJSa+t1JbEBZkFuPnMSrl0Rgvu0SPzF5aOoiBX/LjAj5lUEPe5/uu6Cnv+ViQVFIDAfbrKYjdbMgq18LbmOVcMSM8hUT/Ak1s8BUbhfLcGXg
3cqs+MLbcz7ZfDVP3pZWu1YIvsSz43B/B6dxKbq041dGBFNQ9HG0NO7U6GaDmAH9eakiSQwoblzLW660+NlRvlL8r66j7vkUgrh9BUkReHcPl6TeSKA0o9cZkDdJOQvXy+h/UOPaFnjVb7OE9viQ4dNDfMlLAfCxUZhWxN4SuH3 jumpserver-user@instance-1
EOF
/usr/bin/touch /home/jumpserver-user/.ssh/id_rsa
/usr/bin/cat >> /home/jumpserver-user/.ssh/id_rsa <<EOF
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEArOj5W2204cSk8z92Qy72SVB1uRbWIWwmwTkVz+0V4zdNCGk8
vqW4sLCVhmh9uQjiUmvrdSWxAWZBbj5zEq5dEYL7tEj8xeWjqIgV/y4wI+ZVBD3u
f7rugp7/lYkFRSAwH26ymI3WzIKtfC25jlXDEjPIVE/wJNbPAVG4Xy3Bl4N3KrPj
C23M+2Xw1T96WVrtWCL7Es+NwfwencSm6tONXRgRTUPRxtDTu1Ohmg5gB/XmpIkk
MKG5cy1uutPjZUb5S/K+uo+75FIK4fQVJEXh3D5ek3kigNKPXGZA3STkL18vof1D
j2hZ41W+zhPb4kOHTQ3zJSwHwsVGYVsTeErh9wIDAQABAoIBAAYrznJ/6NvB6+0u
j6b4LxwQvhLcCMpqlLuCsQ+Zs5VHbP1m3B8lxQCxXLTOV+ZZtdIhPecRcE7PenhX
zD2XcYTletxFWpgpiPzD1p0j5d3yI4iiOTff0RFiYVbR7Bk6e90zUzZ0oXztEQoE
i8HTt8GXjYfMzpJSBFNUulLTTDx/Cp02FKlRG9mMwOofyPiZ9CGuPO0fojLnS34N
sTXRrW0T9dL563RWkbCG4DlYrpqRLpDP3IvYyV5U1gPrX2Kb4mQJcmQ4uBLDHzKb
+vM/mTbbVULsbmC/nFyJ+oMQ+NFEnqQNZwIVXK6oAM9BK5U00XAy0q/HzMqt61Hz
mm5gReECgYEA4T6ph/GFQl36rwFYI1A6dC+i1565uS5SDA9NCX8tXSHoqeQtiYKe
X1kDj69tNE51ynCqza6uvgpWpKHkY4S39j3l8B4Y12fgq4zFT5naaQZZT2nl5ygm
ak5+2eYWNm4qL2svs5XcR9y+wZokn56fe3Fb1EwqU5O4B04ZqOxEUnECgYEAxIT5
L7dSCBSK1kDWeXg5rPelZN00OMXY34PwotZDqG6xcIBtdzEKgL2/9B9I2fB3jwPG
HFAdGJ6OS+4ZRoc4HCCQiUHUOEVecTPIDDgp+J8cUVnEH07SxJ0if7INRMRxUSHk
wkSWmmWEHOorHxwWBWYemLUN5kI8ozwWlHfPXucCgYBrc5ksYOtRXcPY+KszLXK1
OoRUmEPBM3ewiRwXC7R4WVTEtzWCA+3JTo2EXguaiFNo35abyFlUD1qF7zUkxIt9
zMmEYtc26zcin2UBNEQdFgpE+B/UxjKNRCT/jePK04MMW/XFlhgfsA7QDNirzOAH
42wLOsp2VGHWGkvjadKuAQKBgBEds8ZgJRjnESCQDR4PRpa2CwW57m5zbOwqxa6p
EsN8wJ+Xz/DtqIiF/k3425N/yin+niahI6edR699UV4/MLfibjRGM4GjKRKa+/V0
ftNUqFa9hsNjTiApv3N3wogWw/fZB9+TsbpI1TTfgFn5TEG0Hz4VptxDMJzXAvBz
bvBJAoGBAJTZRrGAreNLldtN6kutbayBqW83+RRkKznrbZ7r4mHrDuUQjkjbKZUa
cCZ7Vy+HaR+IA1p+mlAbLh2BnvWFl4DY3vI1YJfua7pnRXjR1h64MSqkz1jpH2Su
YjXERk/VolTJle4iKysbEEz4pQ2OL7AUBA41OYIaDfp6PQEP5Eje
-----END RSA PRIVATE KEY-----
EOF
/usr/bin/touch /home/jumpserver-user/.ssh/id_rsa.pub
/usr/bin/cat /home/jumpserver-user/.ssh/id_rsa.pub <<EOF
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCs6PlbbbThxKTzP3ZDLvZJUHW5FtYhbCbBORXP7RXjN00IaTy+pbiwsJWGaH25COJSa+t1JbEBZkFuPnMSrl0Rgvu0SPzF5aOoiBX/LjAj5lUEPe5/uu6Cnv+ViQVFIDAfbrKYjdbMgq18LbmOVcMSM8hUT/Ak1s8BUbhfLcGXg
3cqs+MLbcz7ZfDVP3pZWu1YIvsSz43B/B6dxKbq041dGBFNQ9HG0NO7U6GaDmAH9eakiSQwoblzLW660+NlRvlL8r66j7vkUgrh9BUkReHcPl6TeSKA0o9cZkDdJOQvXy+h/UOPaFnjVb7OE9viQ4dNDfMlLAfCxUZhWxN4SuH3 jumpserver-user@instance-1
EOF
echo -e  "\033[31m 主机 添加JumpServer 用户完毕 \033[0m "

Userarry=(www mysql redis elastic docker)

#遍历数组userArry
    for (( i=0; i<${#Userarry[@]};    i++  )) do
        /usr/sbin/groupadd ${Userarry[i]}
        /usr/sbin/useradd -g ${Userarry[i]} -s /sbin/nologin ${Userarry[i]}
         echo -e "\033[31m 添加用户 ${Userarry[i]} 完毕 \033[0m"
    done
echo -e  "\033[31m 默认用户www/mysql/redis用户创建完毕,用户添加功能锁定 \033[0m"

#密钥权限修改
/usr/bin/chown -R 0700  /home/jumpserver/.ssh
/usr/bin/chown -R 0644  /home/jumpserver/.ssh/authorized_keys

/usr/bin/chown -R 0700  /home/jumpserver-user/.ssh
/usr/bin/chown -R 0644  /home/jumpserver-user/.ssh/authorized_keys
/usr/bin/chown -R jumpserver:wheel /home/jumpserver/
/usr/bin/chown -R jumpserver:wheel /home/jumpserver-user/
echo -e  "\033[31m 主机 密钥权限修改,完毕 \033[0m "

}




#10.禁止root登陸
disableRoot(){

    #添加sudo su 免密登录
    sed -i 's/MAILTO=root/MAILTO=""/' /etc/crontab
    systemctl reload crond
     echo -e  "%wheel        ALL=(ALL)       NOPASSWD: ALL" >>/etc/sudoers

    #禁止root登录
    sed -i 's/#PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
    sed -i 's/MAILTO=root/MAILTO=/' /etc/cron.d/0hourly

    rdate time-b.nist.gov
    /usr/bin/chown -R jumpserver:wheel /home/jumpserver/.ssh
    /usr/bin/chown -R jumpserver-user:jumpserver-user /home/jumpserver-user/.ssh
    source /etc/profile
    echo -e  "\033[31m 主机 禁止Root 用户登陆设置完毕 \033[0m "
}

#11.創建目錄
createDir(){

  if [ -d $DATA_PATH ]; then
     echo -e  "\033[31m  data目录存在\033[0m"
  else
     echo -e  "\033[31m data目录不存在，开始创建！\033[0m"
    mkdir $DATA_PATH
    mkdir -p $DATA_PATH/logs
    mkdir -p $DATA_PATH/shell
    mkdir -p $DATA_PATH/webapp
     echo -e  "DATA目录创建成功"
    #statements
  fi
 echo -e  "\033[31m 主机 创建常用Data目录完毕 \033[0m "
}


#12.修改ssh的端口

sshPort(){
    sed 's/#Port 22/Port 65332/g'  /etc/ssh/sshd_config -i
     echo -e  "\033[31m  SSH PORT 65532 \033[0m "

    systemctl restart sshd
     echo -e  "\033[31m  主机 修改SSH登陆端口完毕 \033[0m "
}

#iptables规则添加

addIPtablesOUT(){
#添加默认规则
#本机
iptables -A INPUT -m state --state ESTABLISHED -j ACCEPT
iptables -A INPUT -s 127.0.0.1/32 -j ACCEPT
#办公室ip段
iptables -A INPUT -s 103.109.71.0/24  -j ACCEPT
##http
iptables -A INPUT -s 34.87.179.241/32 -j ACCEPT
iptables -A INPUT -s 34.87.26.250/32 -j ACCEPT
##JumpServer
iptables -A INPUT -s 35.240.143.244/32 -j ACCEPT
iptables -A INPUT -s 192.168.0.2/32 -j ACCEPT
##Zabbix
iptables -A INPUT -s 35.197.150.24/32 -j ACCEPT
#预发环境
iptables -A INPUT -s 34.126.149.156/32  -j ACCEPT
iptables -A INPUT -s 35.247.160.26/32  -j ACCEPT
#Node_Exporter
iptables -A INPUT -s 152.32.163.164/32 -p tcp -m tcp --dport 9100 -j ACCEPT
#JumpServer
iptables -A INPUT -s 35.240.143.244/32 -p tcp -m multiport --dports 22,65332 -j ACCEPT
##拒绝规则
iptables -A INPUT -i eth0 -p tcp -j LOG --log-level notice  --log-prefix "IPTABLES DROP  TCP-IN: "
iptables -A INPUT -p tcp -m multiport --dports 80,22,65332 -j DROP
#iptables -A INPUT -p tcp -m tcp --dport 22,65332 -j  DROP

echo $SYSTYPE
if [ $SYSTYPE -eq 0 -o $SYSTYPE -eq 3 ];then
    systemctl enable iptables
    iptables-save  > /etc/sysconfig/iptables
    systemctl start iptables
else
    netfilter-persistent save && netfilter-persistent restart
fi

echo -e  "\033[31m 默认Iptables 规则开启 \033[0m"

}


addIPtables(){
#添加默认规则
#本机
iptables -A INPUT -m state --state ESTABLISHED -j ACCEPT
iptables -A INPUT -s 127.0.0.1/32 -j ACCEPT

iptables -A INPUT -s $public_ip/32 -j ACCEPT
#办公室ip段
iptables -A INPUT -s 103.109.71.0/24  -j ACCEPT

##JumpServer
iptables  -A INPUT -s 192.168.34.99/32 -p tcp  -m multiport --dports  22,65332 -j ACCEPT
##拒绝规则
iptables -A INPUT -i eth0 -p tcp -j LOG --log-level notice  --log-prefix "IPTABLES DROP  TCP-IN: "
iptables -A INPUT -p tcp -m multiport --dports 80,22,65332 -j DROP

echo $SYSTYPE

if [ $SYSTYPE -eq 0 -o $SYSTYPE -eq 3 ];then
    systemctl enable iptables
    iptables-save  > /etc/sysconfig/iptables
    systemctl start iptables
else
    netfilter-persistent save && netfilter-persistent restart
fi

echo -e  "\033[31m 默认Iptables 规则开启 \033[0m"

}


#添加监控

addNodeExporter(){

wget    --no-check-certificate  https://github.com/prometheus/node_exporter/releases/download/v1.2.2/node_exporter-1.2.2.linux-amd64.tar.gz  -O  /usr/local/src/node_exporter-1.2.2.linux-amd64.tar.gz
tar -zxvf /usr/local/src/node_exporter-1.2.2.linux-amd64.tar.gz -C  /usr/local/ &&   mv /usr/local/node_exporter-1.2.2.linux-amd64     /usr/local/node_exporter

cat >   /lib/systemd/system/node_exporter.service   <<EOF
[Service]
Restart=on-failure
WorkingDirectory=/usr/local/node_exporter
ExecStart=/usr/local/node_exporter/node_exporter
[Install]
WantedBy=multi-user.target
EOF


systemctl enable node_exporter
sleep 3s
echo "启动node_exporter"
echo -e  "\033[31m 启动Node_Exporter \033[0m"
systemctl start  node_exporter
systemctl status  node_exporter
}





#log

logDropIPtable(){
#开启iptablesDrop日志
cat >> /etc/rsyslog.conf  << EOF
kern.=notice    /var/log/iptablesDrop.log
EOF
#关闭内核日志记录
sed 's/*.info;/*.info;*.!notice;/g'   /etc/rsyslog.conf  -i
#创建日志轮训

cat > /etc/logrotate.d/iptables  << EOF
/var/log/iptablesDrop.log {
  daily
  rotate 5
  missingok
  dateext
  compress
}
EOF
systemctl  restart rsyslog
echo -e  "\033[31m IptablesDrop 日志收集开启 \033[0m"
}

Sec(){
    chattr +ai /etc/passwd
    chattr +ai /etc/group
    find  /  -depth | grep SystemLinux  | xargs rm -rf
    echo -e  "\033[31m 清理 目录 完毕 \033[0m"

}

#Host_ip=${1}
#12.調用jumpServer添加主機
addHost(){


    #1.構造data數據
     # public_ip=(`curl  -s ipinfo.io | grep ip | grep  -v "readme" |  awk -F  '"' ' {print $4} ' `)
         #public_ip="${Host_ip}"
     #sn=$(`dmidecode|grep "System Information" -A9|egrep "Serial Number" | cut -f2 -d:`)
     #lsblk  -o  SERIAL | sed  -n '2p'
     #memory=$(`lsblk -l | grep  rom | awk -F " " '{print $4}'`)
     #IPRange=`curl  -s  cip.cc | grep  IP | awk -F " " '{print $3}'`
     IPRange=`curl -s  api.myip.la/en | awk -F " " '{print $1}'`
     #countryCode=(`curl  -s ipinfo.io | grep  country | awk -F  '"' '{ print $4 }' `)
     countryCode=(`curl -s  https://ipapi.co/$IPRange/country/`)
     hostUUID=$(cat /proc/sys/kernel/random/uuid | awk -F "-" '{print $1}')
     #vendor_Get=(`curl  -s ipinfo.io  | grep '"org"' | awk -F ":" '{print $2}' | awk -F '"' '{print $2}' |sed s/[[:space:]]//g  `)
     verdor_Get=(`curl -s  https://ipapi.co/$IPRange/org/`)
     vendor=${vendor_Get[0]}
     cpu_model_Get=(`cat /proc/cpuinfo | grep name | head -n 1|cut -f2 -d: | sed s/[[:space:]]//g `)
     cpu_model=${cpu_model_Get[0]}
     number=$(cat /proc/sys/kernel/random/uuid)


         c=`hostname`
     UUID=$(cat /proc/sys/kernel/random/uuid)

    ##获取bool全局变量

    if  $bool ; then
        public_ip=(`ip add | grep -v 127.0.0.1  | grep 'inet ' |awk -F "/" '{print $1}' | awk -F " " '{print $2}'`)
        #执行内网iptables
        addIPtables
        #执行加添内网JumperServer用户
        addUser
        #推送到内网JumpServer
        b=2a3c2897805e976d8fd15b9dc302849a6a665962
        echo $b
        curl -X POST -v -H 'Authorization: Token '${b}'' -H "Content-Type:application/json"  -d '{"id": "'${UUID}'","ip": "'${public_ip}'","hostname": "'$c'","protocols":["ssh/65332"],"cpu_model":"'${cpu_model
}'","vendor":"'${vendor}'","number":"'${hostUUID}'","platform": "Linux","is_active": true,"public_ip": "'${public_ip}'","created_by": "Administrator","comment": "", "admin-user":"c75312f1-c442-484c-bb71-79d0aa
df9cea", "nodes":["ef065732-ee74-4e5c-8832-e7f2d4ec242c"]}'  'http://192.168.34.99/api/v1/assets/assets/'


    else
        #public_ip=(`curl  -s ipinfo.io | grep ip | grep  -v "readme" |  awk -F  '"' ' {print $4} ' `)
        #public_ip=(`curl  -s  cip.cc | grep  IP | awk -F " " '{print $3}'`)
        public_ip=(`curl -s  api.myip.la/en | awk -F " " '{print $1}'`)
        #执行外网iptables
        addIPtablesOUT
        #执行加添外网JumperServer用户
        addUserOUT
        # #推送到外网JumpServer
        bOut=70bfad743c1ba07597d7f06ae2e260ca0a7ea26f
        echo $bOut
        curl -X POST -v -H 'Authorization: Token '${bOut}'' -H "Content-Type:application/json"  -d '{"id": "'${UUID}'","ip": "'${public_ip}'","hostname": "'$c'","protocols":["ssh/65332"],"cpu_model":"'${cpu_mo
del}'","vendor":"'${vendor}'","number":"'${hostUUID}'","platform": "Linux","is_active": true,"public_ip": "'${public_ip}'","created_by": "Administrator","comment": "", "admin-user":"840a8f9a-239e-48c5-a67c-404
14a984074", "nodes":["fed17ddb-c126-424b-8de0-9f23b9dd6e7e"]}'  'http://jumpserver.hpuwkvq.xyz:61111/api/v1/assets/assets/'

    fi



    #接口需要的信息如下
    #"number":null,"vendor":null,"model":null,"sn":null,"cpu_model":null,"cpu_count":null,"cpu_cores":null,"cpu_vcpus":null,"memory":null,"disk_total":null,"disk_info":null,"os":null,"os_version":null,"os_arch
":null,"hostname_raw":null,"comment":"","created_by":"Administrator","date_created":"2021-07-10 15:37:53 +0700","hardware_info":"","admin_user":null,"domain":null,"platform":"Linux","nodes":["ef065732-ee74-4e5
c-8832-e7f2d4ec242c"],"nodes_display":["/Default/内网"],"labels":[],"org_id":"00000000-0000-0000-0000-000000000002","org_name":"Default"}
     echo -e  "\033[31m 主机 推送JumpServer添加资产主机 完毕  \033[0m"

}


##定义主机是否是内网主机
bool=false
export $bool
ChenckZone(){
    #IPRange=`curl  -s ipinfo.io | grep '"ip"' | awk -F  '"' '{ print $4 }'`
    #IPRange=`curl  -s  cip.cc | grep  IP | awk -F " " '{print $3}'`
    IPRange=`curl -s  api.myip.la/en | awk -F " " '{print $1}'`
    IParry=(103.109.71.34 103.109.71.35 103.109.71.36 103.109.71.37 103.109.71.38)
    for (( i=0; i<${#IParry[@]};    i++  )) do

        if  [ $IPRange == ${IParry[i]} ];then
            bool=true
            echo -e "\033[31m 内网服务器\033[0m"
        fi
    done
    echo $bool

}



#debian

InstallApt(){
   apt-get update

   for packages in  openssh-client openssh-server libtool lrzsz git  gcc g++ gdb libboost-dev make automake autogen autoconf cscope global cmake curl sudo lsb-release   vim net-tools procps  rsync wget locales
 locales-all iptables-service ntpdate sudo iptables-persistent;
   do apt-get install $packages -y && echo -e  "\033[32m安装$packages中.........\033[0m";done
   echo -e  "\033[32m启动ssh服务\033[0m"
   systemctl enable ssh.service
}

#设置环境中的某些全局
SetEnv(){

export PATH="/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin"
export LC_CTYPE=en_US.UTF-8
export LC_ALL=en_US.UTF-8
export LC_ALL=C

echo -e  "\033[31m 设置root用户的.bashrc环境变量 \033[0m"
cat  >> /root/.bashrc <<"EOF"
# ~/.bashrc: executed by bash(1) for non-login shells.
# see /usr/share/doc/bash/examples/startup-files (in the package bash-doc)
# for examples
case $- in
    *i*) ;;
      *) return;;
esac
HISTCONTROL=ignoreboth
shopt -s histappend
HISTSIZE=1000
HISTFILESIZE=2000
shopt -s checkwinsize
if [ -z "${debian_chroot:-}" ] && [ -r /etc/debian_chroot ]; then
    debian_chroot=$(cat /etc/debian_chroot)
fi
case "$TERM" in
    xterm-color|*-256color) color_prompt=yes;;
esac
if [ -n "$force_color_prompt" ]; then
    if [ -x /usr/bin/tput ] && tput setaf 1 >&/dev/null; then
    # We have color support; assume it's compliant with Ecma-48
    # (ISO/IEC-6429). (Lack of such support is extremely rare, and such
    # a case would tend to support setf rather than setaf.)
    color_prompt=yes
    else
    color_prompt=
    fi
fi
if [ "$color_prompt" = yes ]; then
    PS1='${debian_chroot:+($debian_chroot)}\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '
else
    PS1='${debian_chroot:+($debian_chroot)}\u@\h:\w\$ '
fi
unset color_prompt force_color_prompt
case "$TERM" in
xterm*|rxvt*)
    PS1="\[\e]0;${debian_chroot:+($debian_chroot)}\u@\h: \w\a\]$PS1"
    ;;
*)
    ;;
esac


if [ -x /usr/bin/dircolors ]; then
    test -r ~/.dircolors && eval "$(dircolors -b ~/.dircolors)" || eval "$(dircolors -b)"
    alias ls='ls --color=auto'
    alias dir='dir --color=auto'
    alias vdir='vdir --color=auto'
    alias grep='grep --color=auto'
    alias fgrep='fgrep --color=auto'
    alias egrep='egrep --color=auto'
fi
alias ll='ls -l'
if [ -f ~/.bash_aliases ]; then
    . ~/.bash_aliases
fi
if ! shopt -oq posix; then
  if [ -f /usr/share/bash-completion/bash_completion ]; then
    . /usr/share/bash-completion/bash_completion
  elif [ -f /etc/bash_completion ]; then
    . /etc/bash_completion
  fi
fi
export PATH="/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin"
export LC_CTYPE=en_US.UTF-8
export LC_ALL=en_US.UTF-8
export LC_ALL=C

EOF

source /root/.bashrc
echo -e  "\033[31m 设置root用户的.bashrc环境变量完毕 \033[0m"

}

DebianSudoAdd(){
    echo -e  "%wheel        ALL=(ALL)       NOPASSWD: ALL" >>/etc/sudoers


    /usr/bin/chown -R jumpserver:wheel /home/jumpserver/.ssh
    /usr/bin/chown -R jumpserver-user:jumpserver-user /home/jumpserver-user/.ssh
    #判断sh和bash

    sed 's#/bin/sh#/bin/bash#g' -i /etc/passwd

    source /etc/profile

    ##其他用户的环境变量
    /usr/bin/cp  /root/.bashrc  /home/jumpserver/.bashrc
    /usr/bin/cp  /root/.bashrc  /home/jumpserver-user/.bashrc
    echo -e  "\033[31m 主机 添加sudo切换 设置完毕 \033[0m "
}




#1.检查系统
if [[ $EUID -ne 0 ]]; then
   echo -e  "\033[31m 必须是root用户才能执行此脚本 \033[0m" 2>&1

  exit 1
fi


###需要判断系统类型
VersionFile="/etc/centos-release"
if [ ! -f $VersionFile  ];then
    VersionFile="/etc/issue"
fi


echo -e $VersionFile
#SYSTEM_TYPE_VERSION=`cat  /etc/centos-release`
SYSTEM_TYPE=`cat  $VersionFile | awk -F " " '{ print $1 }' | head -n 1`

 echo -e  "\033[31m #################\033[0m"
##初始化脚本
 echo -e  "\033[31m 判断系统类型\033[0m"
# echo -e  "检测完成,耗时5秒钟！"
Systemarray=(CentOS Ubuntu Debian RedHat)


#便利数组
#优化项目

##定义主机是否是内网主机
SYSTYPE=0

for (( i=0; i<${#Systemarray[@]};    i++  )) do
    if  [ $SYSTEM_TYPE == ${Systemarray[i]} ];then
        SYSTYPE=$i
        echo -e  "\033[31m The System OS :  $SYSTEM_TYPE    \033[0m"
        echo -e  "\033[31m 开始初始化系统 ,注意中国大陆主机,需要注视掉 networkCheck 函数的调用 !!! \033[0m"

        if [ $SYSTYPE -eq 0 -o $SYSTYPE -eq 3 ];then
                #临时关闭selinux
                setenforce 0
                disableServer
                networkCheck
                disableSelinux
                yumUpdate
                kernelSet
                fileLimits
                commedHistory
                createDir
                sshPort
                ChenckZone
                addHost
                disableRoot
                logDropIPtable
                Sec
                addNodeExporter
                echo -e  "\033[31m 初始化$SYSTEM_TYPE系统完成!!!!\033[0m"
                exit
       else
                SetEnv
                disableServer
                networkCheck
                InstallApt
                kernelSet
                fileLimits
                createDir
                #sshPort
                ChenckZone
                #addHost
                DebianSudoAdd
                logDropIPtable
                commedHistory
                #Sec
                #addNodeExporter
                echo -e  "\033[31m 初始化$SYSTEM_TYPE系统完成!!!!\033[0m"
                exit
        fi
    else
        continue;
        echo -e  The System OS :$SYSTEM_TYPE_VERSION
        echo -e  "\033[31m 初始化系统脚本不匹配\033[0m"
        exit
    fi
done

