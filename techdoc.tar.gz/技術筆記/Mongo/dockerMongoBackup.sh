#!/bin/bash

##env set
mongobin="/usr/local/mongodb/bin"
host=localhost
mongouser="root"
mongopwd="mongodb@evescn"
mongoport=27018

fullbakdir=/data/backup/full-`date +%F`
inc_bakdir=/data/backup/inc-`date +"%Y-%m-%d-%H_%M_%S"`

#starttime=`date-d '-1 hours' +%s`
starttime=`date -d '-62 Minutes' +%s`
checktime=3900

docinclback(){
    docker exec -it mongo_rs1 mongodump -d local -c oplog.rs --gzip \
        --query '{"ts": {"$gte": {"$timestamp": {"t": '"$starttime"' , "i": 1}}}}' \
        --out=${inc_bakdir}
    exit 0
}

# docker全量备份
docfullback(){
  docker exec -it mongo_rs1 mongodump -j 8 --gzip --out=$fullbakdir
  exit 0
}

# docker全量备份
docfulloplogback(){
  docker exec -it mongo_rs1 mongodump -j 8 --oplog --gzip --out=$fullbakdir
  exit 0
}

check_dumpcommand(){
  if command -v docker > /dev/null && docker exec -it mongo_rs1 mongodump > /dev/null; then
    echo "yes mongodump存在容器裡"
        if [ ${signal} = full ]; then
          docfullback
        elif [ ${signal} = inc ];
        then
          docinclback
          if [ $? -eq 0 ]; then
            inclback
          else
            echo "send msg"
          fi
        else
          echo "请指定备份类型"
        fi
  else
    echo "NO bash"
    exit 0
  fi
}

check_docker(){
    if ps -ef | grep mongod | grep -v 'grep' > /dev/null; then
        echo "docker yes"
        if netstat -naltp | grep -e 27017 -e 27018 -e 27019; then
            mongoport=27017
        fi
        if netstat -naltp | grep -e 27117 -e 27118 -e 27119; then
            mongoport=27117
        fi
        echo "MongoPort 存在於：" $mongoport
        ### 繼續執行備份指令檢查
        check_dumpcommand
    else
        echo "NONONO"
        exit 0
    fi
}

# 檢查是否存在 mongodump 指令
check_command() {
    if ! command -v $1 &> /dev/null; then
        echo "$1 指令不存在，改檢查是否使用docker."
        check_docker
    fi
}

signal=${1:-full}
# 檢查 mongodump 指令是否存在
check_command mongodump
#check_command $mongobin/mongodump

##创建业务目录
function fulldir()
{
  if [ ! -d "${fullbakdir}" ];
  then
    mkdir -p ${fullbakdir}
  else
    echo"已经存在备份目录,本次备份退出,请检查环境"
    exit
  fi
}

function incdir()
{
  if [ ! -d "${inc_bakdir}" ];
  then
    mkdir -p ${inc_bakdir}
  fi
}

# 全量备份
function fullback()
{
  ${mongobin}/mongodump  --host=${host} --port=${mongoport} --authenticationDatabase admin -u ${mongouser} -p ${mongopwd} -j 8 --oplog --gzip --out=${fullbakdir}
}

function inclback()
{
  ${mongobin}/mongodump  --host=${host} \
                         --port=${mongoport} \
                         --authenticationDatabase admin \
                         -u ${mongouser} \
                         -p ${mongopwd} \
                         -d local -c oplog.rs --gzip \
                         --query '{"ts": {"$gte": {"$timestamp": {"t": '"$starttime"' , "i": 1}}}}' \
                         --out=${inc_bakdir}
}

function chkoplog()
{
  oplogtime=`${mongobin}/mongosh  --host=${host} --port=${mongoport} --authenticationDatabase admin -u ${mongouser} -p ${mongopwd} --eval "rs.printReplicationInfo()"|grep -A 1 "log length start to end" |xargs |awk {'print $6'} |awk -F's' {'print $1'}`

  echo $oplogtime

  if [ ${oplogtime} -gt ${checktime} ]
  then
    return 0
  else
    return 1
  fi
}

signal=${1:-full}
if [ ${signal} = full ];
then
  fulldir
  fullback
elif [ ${signal} = inc ];
then
  incdir
  chkoplog
  if [ $? -eq 0 ];
  then
    inclback
  else
    echo"send msg"
  fi
else
  echo"请指定备份类型"
fi