#!/bin/bash

##env set

mongobin="/usr/local/mongodb/bin"
host=localhost
mongouser="root"
mongopwd="mongodb@evescn"
mongoport=27018

fullbakdir="/home/mongo/backup/full-$(date +%F)"
inc_bakdir="/home/mongo/backup/inc-$(date +"%Y-%m-%d-%H_%M_%S")"

# starttime=$(date -d '-1 hours' +%s)
checktime=3900

##创建业务目录
function fulldir() {
  if [ ! -d "${fullbakdir}" ]; then
    mkdir -p "${fullbakdir}"
  else
    echo "已经存在备份目录,本次备份退出,请检查环境"
    exit 1
  fi
}

function incdir() {
  if [ ! -d "${inc_bakdir}" ]; then
    mkdir -p "${inc_bakdir}"
  fi
}

# 全量备份
function fullback() {
  "${mongobin}/mongodump" --host="${host}" \
                         --port="${mongoport}" \
                         --authenticationDatabase admin \
                         -u "${mongouser}" \
                         -p "${mongopwd}" \
                         -j 8 \
                         --oplog \
                         --gzip \
                         --out="${fullbakdir}"
}

# 增量备份
function inclback() {
  # 获取指定时间戳
  starttime=$(date -d '-62 Minutes' +%s)


  # 备份当前的 oplog
  "${mongobin}/mongodump" --host="${host}" \
                         --port="${mongoport}" \
                         --authenticationDatabase admin \
                         -u "${mongouser}" \
                         -p "${mongopwd}" \
                         --db=local --collection=oplog.rs \
                         --query '{"ts": {"$gte": {"$timestamp": {"t": '"$starttime"' , "i": 1}}}}' \
                         --out="${inc_bakdir}"

#  "${mongobin}/mongodump" --host="${host}" \
#                         --port="${mongoport}" \
#                         --authenticationDatabase admin \
#                         -u "${mongouser}" \
#                         -p "${mongopwd}" \
#                         --db=local --collection=oplog.rs \
#                         --query '{"ts": {"$gte": {"$timestamp": {"t": '"$starttime"' , "i": 1}}}}' \
#                         #--gzip \
#                         --out="${inc_bakdir}" \
#                         --oplog \
#

  # 在备份目录下创建 timestamp 文件，记录备份时间
  #echo "${starttime}" > "${inc_bakdir}/timestamp"
}

function chkoplog() {
  oplogtime=$("${mongobin}/mongosh" --host="${host}" \
                                    --port="${mongoport}" \
                                    --authenticationDatabase admin \
                                    -u "${mongouser}" \
                                    -p "${mongopwd}" \
                                    --quiet \
                                    --eval "rs.printReplicationInfo()" | grep -A 1 "log length start to end" | xargs | awk '{print $6}' | awk -F's' '{print $1}')

  echo "$oplogtime"

  if [ "${oplogtime}" -gt "${checktime}" ]; then
    return 0
  else
    return 1
  fi
}

signal=${1:-full}
if [ "${signal}" = full ]; then
  fulldir
  fullback
elif [ "${signal}" = inc ]; then
  incdir
  chkoplog
  if [ $? -eq 0 ]; then
    inclback
  else
    echo "send msg"
  fi
else
  echo "请指定备份类型"
fi
