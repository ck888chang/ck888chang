#!/bin/bash
### 2024年1月26日，由CK編寫，如果有問題可以問AI
### 2024年1月26日，ck自測完成，需找其他高手再次確認及驗証

base_DIR="/data/"
mongo_DIR="$base_DIR/mongodb_replicas"
if [ ! -d "$mongo_DIR" ]; then
    mkdir -p "$mongo_DIR"/{db1,db2,db3}
    echo "創建 mongo 目錄"
fi

# 配置 mongo yml 檔案
mongo_FILE="$mongo_DIR/docker-compose.yml"
if [ ! -f "$mongo_FILE" ]; then
    cat > "$mongo_FILE" << EOF
version: '3'
services:
  mongo_rs1:
    image: mongo:7
    container_name: mongo_rs1
    ports:
      - 27117:27017
    restart: always
    networks:
      - mongo-net
    volumes:
      - $mongo_DIR/db1:/data/db
      - $mongo_DIR/backup:/data/backup
      - $mongo_DIR/mongo_rs1.conf:/etc/mongod.conf
    command: ["--replSet", "goplayslots"]

  mongo_rs2:
    image: mongo:7
    container_name: mongo_rs2
    ports:
      - 27118:27017
    restart: always
    networks:
      - mongo-net
    volumes:
      - $mongo_DIR/db2:/data/db
      - $mongo_DIR/backup:/data/backup
      - $mongo_DIR/mongo_rs2.conf:/etc/mongod.conf
    command: ["--replSet", "goplayslots"]

  mongo_rs3:
    image: mongo:7
    container_name: mongo_rs3
    ports:
      - 27119:27017
    restart: always
    networks:
      - mongo-net
    volumes:
      - $mongo_DIR/db3:/data/db
      - $mongo_DIR/backup:/data/backup
      - $mongo_DIR/mongo_rs3.conf:/etc/mongod.conf
    command: ["--replSet", "goplayslots"]

networks:
  mongo-net:
    driver: bridge
EOF
  echo "配置 mongo yml 檔案"
else
  echo "配置 mongo yml 檔案時已存在，不變更"
fi

# 設定要循環的數量
for i in {1..3}; do
    # 配置 mongo config 檔案
    mongo_conf="$mongo_DIR/mongo_rs${i}.conf"

    if [ ! -f "$mongo_conf" ]; then
        cat > "$mongo_conf" << EOF
net:
  bindIp: 0.0.0.0
  port: 27017
replication:
  replSetName: "goplayslots"
EOF
        echo "配置 mongo config${i} 檔案"
    else
        echo "配置 mongo config${i} 檔案時已存在，不變更"
    fi
done

if [ -f "$mongo_FILE" ]; then
    cd "$mongo_DIR"
    output=$(docker compose up -d)

    # 检查命令的返回码
    if [ $? -eq 0 ]; then
        echo "docker compose up -d 上線成功."
        ### 呼叫下一步驟程序
        #loginmessage
        #delfun
    else
        echo -e "\033[31m docker compose up -d 失敗請檢查相關錯誤訊息\033[0m"
        echo "$output"  # 输出命令的标准输出和错误输出
        # 在此添加处理失败的代码
    fi
fi

# 取得本機IP地址
# 方法1 (Linux):
CURRENT_LOCAL_IP=$(ip addr show ens192 | grep -oP 'inet \K[0-9.]+')

# 方法2 (通用):
# CURRENT_LOCAL_IP=$(hostname -I | awk '{print $1}')

echo -e "\033[32mLocal IP address is: $CURRENT_LOCAL_IP"

# 取得外網IP地址
CURRENT_PUBLIC_IP=$(curl -s ifconfig.me)

echo -e "\033[32mPublic IP address is: $CURRENT_PUBLIC_IP"

# 取得Docker容器內部IP地址
for i in {1..3}; do
    container_name="mongo_rs${i}IP"
    eval "${container_name}=\$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' mongo_rs${i})"
    echo "mongo_rs${i} 內部的 IP 為" "${!container_name}"
done

# 提示用戶確認是否繼續執行
read -p "Enter 'internet' for public IP, 'local' for local IP, 'dockerip' for Docker IP: " answer

case $answer in
  internet)
    CLUSTER_IP=$CURRENT_PUBLIC_IP
    ;;
  local)
    CLUSTER_IP=$CURRENT_LOCAL_IP
    ;;
  dockerip)
    echo "Please enter the specific container (e.g., 'mongo_rs1', 'mongo_rs2', 'mongo_rs3'):"
    read container_choice
    container_name="${container_choice}IP"
    CLUSTER_IP="${!container_name}"
    ;;
  *)
    echo "Invalid choice. Exiting script."
    exit 0
    ;;
esac
echo "目前選用Cluster ip 為: $CLUSTER_IP 此ip用做cluster通訊及連結時使用"
#echo $mongo_rs1IP $mongo_rs2IP $mongo_rs3IP

sleep 5
docker exec -i mongo_rs1 mongosh<<EOF
use admin
rs.initiate(
   {
      _id: "goplayslots",
      members: [
         { _id: 0, host: "$CLUSTER_IP:27117" },
         { _id: 1, host: "$CLUSTER_IP:27118" },
         { _id: 2, host: "$CLUSTER_IP:27119", arbiterOnly: true }
      ]
   }
)
EOF

cat > "$mongo_DIR/deleteMongoCluster.sh" << EOF
#!/bin/bash
#deleteMongoCluster.sh刪除 Mongo Cluster，非確定者請勿執行, 上線後請把此檔刪除，避免誤用
docker compose down
rm -rf $mongo_DIR
EOF

### 檢查cluster 狀況是否成功 ，將 rs.status() 的執行結果保存到變數中
rs_status=$(docker exec -i mongo_rs1 mongosh --quiet --eval 'printjson(rs.status())')

echo "$rs_status"
echo "$rs_status" > "$mongo_DIR/rs_status.json"


# 提示用戶確認是否建立admin用戶
read -p "請確認是否建立admin用戶:(yes/no) " CreaterUser

if [ "$CreaterUser" != "yes" ]; then
    echo "再見，結束腳本"
    exit 0
else
  docker exec -i mongo_rs1 mongosh<<EOF
use admin
db.createUser({
  user: 'root',  // 用户名
  pwd: '1234AEDED61',  // 密码
  roles:[{
    role: 'dbAdmin',  // 角色
    db: 'admin'  // 数据库
  },
  {
      "role" : "readWrite",
       "db" : "admin"
    }]
})
EOF
   echo "建立admin用戶完成"
fi
