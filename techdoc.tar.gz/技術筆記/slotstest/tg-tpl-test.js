const TelegramBot = require('node-telegram-bot-api');
const util = require('util');
const moment = require("moment");
const child_process = require('child_process');
const { Worker } = require('worker_threads');
const fs = require('fs');
const {sleep,inArray,formatMilliseconds,getServerSetNames,getCommandArrAndHelpMsg} = require('./lib/clib')
require('dotenv').config();
const unAthInfo = "你的信息已记录，请联系管理员授权!";
const {serverNameStr,slotsAllGameServers} = getServerSetNames();

//读取目录下面的.env中的proenv的值，并确认其环境类型
const branchName=process.env.branchName
let configPath = `./config/config-${branchName}`;
console.log("引入config 文件路径为:",configPath)
const proConfig = require(configPath);
const authChatIds = proConfig.authChatIds;
//.env 读取end

const {commandArr,helpMsg,tgCommandS,tgCommandSReg,gdDeployServerNames} = getCommandArrAndHelpMsg(proConfig.allServices,branchName,proConfig.envName,serverNameStr);
console.log("helpMsg",helpMsg);
console.log("commandArr",commandArr);
console.log("tgCommandS:","\n",tgCommandS);
console.log("tgCommandSReg",tgCommandSReg);
const bot = new TelegramBot(proConfig.tgBotToken, {
    polling: true
});


bot.onText(/\/(help)/, async msg => {
    console.log(msg);
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {
        await bot.sendMessage(chatId, helpMsg);
    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});


bot.onText(/\/(sup_status)/, async msg => {
    console.log(msg);
    const chatId = msg.chat.id;
    let commandStr = '';
    if (inArray(chatId, authChatIds)) {
        let startTime = Date.now();
        let bftips = `收到！正在执行Supervisor状态检查，请稍等...`;
        let aftips = `Hi! 执行Supervisor状态检查完成,`;
        await bot.sendMessage(chatId,bftips);

        let cTime = moment();
        let sendFileName = `./deploy-logs/${msg.from.username}-Supervisor-status-check-${cTime.format('YYYY-MM-DD-HH-mm-ss')}.txt`;


        let clogMsg = '如下为Supervisor中各Service的运行状态\n\n';
        commandStr = `echo '${clogMsg}' > ${sendFileName} &&  supervisorctl status >>  ${sendFileName} 2>&1   || echo ''`;
        console.log("执行",commandStr);
        clogMsg += child_process.execSync(commandStr).toString().trim();

        console.log("clogMsg:-",clogMsg);

        let outmsg =`@${msg.from.username}
${aftips},日志文件如下`;
        await bot.sendMessage(chatId, outmsg);
        //fs.writeFileSync(sendFileName, clogMsg);
        await bot.sendDocument(chatId, sendFileName, {
            contentType: 'text/plain',
        });
        await bot.sendMessage(chatId, '<strong>执行完成（请检查日志文件中的执行情况）</strong>', {parse_mode: 'HTML'});
    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});


bot.onText(/\/(check_status)/, async msg => {
    console.log(msg);
    const chatId = msg.chat.id;
    let commandStr = '';
    if (inArray(chatId, authChatIds)) {
        let startTime = Date.now();
        let bftips = `收到！正在执行发布k8s状态检查，请稍等...`;
        let aftips = `Hi! 执行发布k8s状态检查完成,`;
        await bot.sendMessage(chatId,bftips);
        let clogMsg = '如下为k8s各命名空间中各pods的运行状态\n\n';
        for(var knamespace of proConfig.k8sNameSpaces){
            clogMsg += `在k8s命令空间[${knamespace}]下的pods运行状态如下\n`;
            commandStr = `kubectl get pods -n ${knamespace}`;
            console.log("执行",commandStr);
            clogMsg += child_process.execSync(commandStr).toString().trim();
        }
        let cTime = moment();
        let sendFileName = `./deploy-logs/${msg.from.username}-k8s-status-check-${cTime.format('YYYY-MM-DD-HH-mm-ss')}.txt`;
        console.log("clogMsg:-",clogMsg);

        let outmsg =`@${msg.from.username}
${aftips},日志文件如下`;
        await bot.sendMessage(chatId, outmsg);
        fs.writeFileSync(sendFileName, clogMsg);
        await bot.sendDocument(chatId, sendFileName, {
            contentType: 'text/plain',
        });
        await bot.sendMessage(chatId, '<strong>执行完成（请检查日志文件中的执行情况）</strong>', {parse_mode: 'HTML'});
    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});


bot.onText(/\/(gall)/, async msg => {
    console.log(msg);
    const chatId = msg.chat.id;
    let commandStr = '';
    let cTime = moment();
    if (inArray(chatId, authChatIds)) {
        let startTime = Date.now();
        let gameServer = "all";
        let bftips = `收到！正在执行发布Slots-Games-Go-API 的所有服务的${branchName}分支到${proConfig.envName}，请稍等5-15分钟...`;
        let aftips = `Hi! 发布Slots-Games-Go-API的所有服务于分支[${branchName}]${proConfig.envName}完成`;
        await bot.sendMessage(chatId,bftips);
        let gameServicesAll  = proConfig.gameServicesAll;
        console.log("gameServicesAll",gameServicesAll);
        let cmds = gameServicesAll['cmds']

        let sendFileName = `${__dirname}/deploy-logs/${msg.from.username}-Slots-Games-Go-API-${gameServer}-deploy-${cTime.format('YYYY-MM-DD-HH-mm-ss')}.txt`;
        commandStr = util.format(cmds[0], sendFileName);
        console.log("执行",commandStr);

        let clogMsg = child_process.execSync(commandStr).toString().trim();
        let resultStr = '';
        if(clogMsg.endsWith("0")){
            resultStr = '发布成功';
        }else{
            resultStr = '发布失败';
        }
        console.log(clogMsg);

        //重启两个结点的服务
        /*commandStr = util.format(cmds[1], gameServer,gameServer);
        clogMsg += child_process.execSync(commandStr).toString();
        console.log("执行",commandStr);

        commandStr = util.format(cmds[2], gameServer,gameServer);
        clogMsg += child_process.execSync(commandStr).toString();
        console.log("执行",commandStr);*/



        let outmsg =`@${msg.from.username}
${aftips},日志文件如下`;
        await bot.sendMessage(chatId, outmsg);

        await bot.sendDocument(chatId, sendFileName, {
            contentType: 'text/plain',
        });
        if(resultStr === "发布成功"){
            await bot.sendMessage(chatId, '<strong>发布成功</strong>', {parse_mode: 'HTML'});
        }else{
            await bot.sendMessage(chatId, '<strong><code>发布失败</code></strong>', {parse_mode: 'HTML'});
        }
        let endTime = Date.now();
        let executionTime = endTime - startTime;
        await bot.sendMessage(chatId, `本次执行时间，耗时: ${formatMilliseconds(executionTime)}`);
    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});

bot.onText(new RegExp(`/(${tgCommandSReg})`,'i'),async (msg, match) => {
    var resp = match[1].trim();
    console.log(msg,match);
    const chatId = msg.chat.id;
    let commandStr = '';
    if (inArray(chatId, authChatIds)) {
        let startTime = Date.now();
        if(resp.startsWith("gd_deploy")){
            let gameServer = gdDeployServerNames[resp]['name'];
            let bftips = util.format(commandArr["gd_deploy"]['bftips'], gameServer);
            let aftips = util.format(commandArr["gd_deploy"]['aftips'], gameServer);
            await bot.sendMessage(chatId,bftips);
            if(inArray(branchName,['test'])){
                let cmds = commandArr["gd_deploy"]['cmds']
                commandStr = util.format(cmds[0],gameServer);
                console.log("执行",commandStr);
                let clogMsg = child_process.execSync(commandStr).toString().trim();
                let resultStr = '';
                if(clogMsg.endsWith("0")){
                    resultStr = '发布成功';
                }else{
                    resultStr = '发布失败';
                }
                clogMsg = clogMsg.substr(0, clogMsg.length - 1);

                //重启两个结点的服务
                /*commandStr = util.format(cmds[1], gameServer,gameServer);
                clogMsg += child_process.execSync(commandStr).toString();
                console.log("执行",commandStr);

                commandStr = util.format(cmds[2], gameServer,gameServer);
                clogMsg += child_process.execSync(commandStr).toString();
                console.log("执行",commandStr);*/

                if(gameServer == 'AlgoServer'){
                    try{
                        commandStr = 'sleep 10 && supervisorctl restart RocketServer'
                        child_process.execSync(commandStr);
                    }catch(e){
                        console.log(e);
                    }
                }


                let cTime = moment();
                let sendFileName = `./deploy-logs/${msg.from.username}-${gameServer}-deploy-${cTime.format('YYYY-MM-DD-HH-mm-ss')}.txt`;
                console.log(clogMsg);

                let outmsg =`@${msg.from.username}
${aftips},日志文件如下`;
                await bot.sendMessage(chatId, outmsg);

                fs.writeFileSync(sendFileName, clogMsg);
                await bot.sendDocument(chatId, sendFileName, {
                    contentType: 'text/plain',
                });
                if(resultStr === "发布成功"){
                    await bot.sendMessage(chatId, '<strong>发布成功</strong>', {parse_mode: 'HTML'});
                }else{
                    await bot.sendMessage(chatId, '<strong><code>发布失败</code></strong>', {parse_mode: 'HTML'});
                }
            }
        }else{
            let gameServer = gdDeployServerNames[resp]['name'];
            await bot.sendMessage(chatId, commandArr[resp]['bftips']);
            let aftips = commandArr[resp]['aftips'];
            let cmds = commandArr[resp]['cmds'];
            commandStr = cmds[0];
            console.log("执行",commandStr);
            let clogMsg = child_process.execSync(commandStr).toString().trim();
            let cTime = moment();
            let sendFileName = `./deploy-logs/${msg.from.username}-${gameServer}-deploy-${cTime.format('YYYY-MM-DD-HH-mm-ss')}.txt`;
            console.log("clogMsg:-",clogMsg);

            let outmsg =`@${msg.from.username}
${aftips},日志文件如下`;
            await bot.sendMessage(chatId, outmsg);
            fs.writeFileSync(sendFileName, clogMsg);
            await bot.sendDocument(chatId, sendFileName, {
                contentType: 'text/plain',
            });
            await bot.sendMessage(chatId, '<strong>发布完成（请检查日志中的发布情况）</strong>', {parse_mode: 'HTML'});
        }
        let endTime = Date.now();
        let executionTime = endTime - startTime;
        await bot.sendMessage(chatId, `本次执行时间，耗时: ${formatMilliseconds(executionTime)}`);
    } else {
        console.log(msg);
        await bot.sendMessage(chatId, unAthInfo);
    }
});