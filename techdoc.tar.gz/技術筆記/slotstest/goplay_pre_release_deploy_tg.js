//[root@prereleasemain ~]# cat /home/jnodes/goplay-deploy-tg/goplay_pre_release_deploy_tg.js

const TelegramBot = require('node-telegram-bot-api');
const util = require('util');
const moment = require("moment");
const child_process = require('child_process');

const token = '6766917072:AAG_vNZUZChi2meAk5yMkgv-10aKi35Id0Y';

const deploy= require('./lib/goplaydeploy');
const ckModule = require('./lib/ck');

const authChatIds = [5021287957,-1002091501418];

const unAthInfo = "你的信息已记录，请联系管理员授权!";

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function inArray(search, array) {
    for (var i in array) {
        if (array[i] == search) {
            return true;
        }
    }
    return false;
}

function formatMilliseconds(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(2);
    return `${minutes} 分 ${seconds} 秒`;
}

const bot = new TelegramBot(token, {
    polling: true
});

const helpMsg = `Only:
    \/gd deploy 服务名  [发布goplay-admin项目的pre-release分支上面的 服务 于预发布环境;服务名: api,back,game,merchant,pay,push,task ; 例如: \/gd deploy api]

    \/dp_h5   [在预发布环境 发布goplay-h5项目 于pre-release分支]

    \/dp_mc   [在预发布环境 发布goplay-web-merchant项目 于pre-release分支]

    \/dp_ad   [在预发布环境 发布goplay-web-admin项目 于pre-release分支]

    \/dp_dash [在预发布环境 发布dashboard项目 于pre-release分支]

    \/dp_gp_pay   [在预发布环境 发布gp-payment-service项目 于pre-release分支]

    \/check_status [检查预发布环境k8s状态]
`

bot.onText(/\/help/, async msg => {
    if (msg.text !== "/help") {
        return;
    }
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {
        await bot.sendMessage(chatId, helpMsg);
    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});

const commonTips = {
    'gd-deploy':{
        'bftips':'收到！正在执行发布goplay-admin 的 %s-service 的 pre-release分支到预发布环境，请稍等1-6分钟...',
        'aftips':'Hi! 发布goplay-admin的%s-service于分支[pre-release]预发布环境完成',
    }
}

const commondCommandS = {
    'gd-deploy':{
        'cmd':`curl -s --location 'http://172.31.20.199:6002/deploy' \
        --header 'token: 13f6bbca576d976eb9461969bc8ee82c' \
        --header 'Content-Type: application/x-www-form-urlencoded' \
        --data-urlencode 'service=%s-service' \
        --data-urlencode 'branch=pre-release'`
    }
}

const commandArr = {
    "api":{
        'bftips':'',
        'cmd':``,
        'aftips':'',
    },
    'back':{},
    'game':{},
    'merchant':{},
    'pay':{},
    'push':{},
    'task':{},

    'dp_h5':{
        'bftips':'收到！正在执行发布goplay-h5 pre-release分支到预发布环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.20.199:6003/deploy' \
        --header 'token: fbe12868cbfe9980b6dfd87e23ce2dc1' \
        --header 'Content-Type: application/x-www-form-urlencoded' \
        --data-urlencode 'branch=pre-release'`,
        'aftips':'Hi! 发布goplay-h5 pre-release分支到预发布环境完成',
    },

    'dp_mc':{
        'bftips':'收到！正在执行发布goplay-web-merchant pre-release分支到预发布环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.20.199:6004/deploy' \
        --header 'token: 5fb02997fcd5ce5f5bc26069b149ede9' \
        --header 'Content-Type: application/x-www-form-urlencoded' \
        --data-urlencode 'branch=pre-release'`,
        'aftips':'Hi! 发布goplay-web-merchant pre-release分支到预发布环境完成',
    },

    'dp_ad':{
        'bftips':'收到！正在执行发布goplay-web-admin pre-release分支到预发布环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.20.199:6005/deploy' \
        --header 'token: 3a57d08fd9999cf513989e4059c59a1a' \
        --header 'Content-Type: application/x-www-form-urlencoded' \
        --data-urlencode 'branch=pre-release'`,
        'aftips':'Hi! 发布goplay-web-admin pre-release分支到预发布环境完成',
    },

    'dp_dash':{
        'bftips':'收到！正在执行发布dashboard pre-release分支到预发布环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.20.199:6007/deploy' \
        --header 'token: fbe12868cbfe9980b6dfd87e23ce2dc1' \
        --header 'Content-Type: application/x-www-form-urlencoded' \
        --data-urlencode 'branch=pre-release'`,
        'aftips':'Hi! 发布dashboard pre-release分支到预发布环境完成',
    },

    'dp_gp_pay':{
        'bftips':'收到！正在执行发布gp-payment-service pre-release分支到预发布环境，请稍等1-8分钟...',
        'cmd':`curl -s --location 'http://172.31.20.199:6006/deploy' \
        --header 'token: 13f6bbca576d976eb9461969bc8ee82c' \
        --header 'Content-Type: application/x-www-form-urlencoded' \
        --data-urlencode 'service=gp-payment-service'  \
        --data-urlencode 'branch=pre-release'`,
        'aftips':'Hi! 发布gp-payment-service pre-release分支到预发布环境完成',
    },


    'check_status':{
        'bftips':'收到！正在执行发布k8s状态检查，请稍等...',
        'cmd':`kubectl get pods -n goplay`,
        'aftips':'Hi! 执行发布k8s状态检查完成',
    },
}

bot.onText(/\/gd (.+)/, async (msg, match) => {
    var resp = match[1].trim();
    console.log(msg,match);
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {
        let paramsArr =  resp.split(" ").filter(e=>e.trim());
        if(paramsArr.length == 2){
            if(paramsArr[0] == "deploy"){
                if(!commandArr[paramsArr[1]]){
                    await bot.sendMessage(chatId, ' \/gd deploy 命令的服务名错误!');
                    return;
                }

                if(commandArr[paramsArr[1]]['bftips']){
                    await bot.sendMessage(chatId, commandArr[paramsArr[1]]['bftips']);
                }else{
                    await bot.sendMessage(chatId, util.format(commonTips[`gd-${paramsArr[0]}`]['bftips'], paramsArr[1]));
                }

                let aftips = '';
                if(commandArr[paramsArr[1]]['aftips']){
                    aftips = commandArr[paramsArr[1]]['aftips'];
                }else{
                    aftips = util.format(commonTips[`gd-${paramsArr[0]}`]['aftips'], paramsArr[1]);
                }

                let startTime = Date.now();
                let command = '';
                if(commandArr[paramsArr[1]]['cmd']){
                    command = commandArr[paramsArr[1]]['cmd'];
                }else{
                    command =  util.format(commondCommandS[`gd-${paramsArr[0]}`]['cmd'], paramsArr[1])
                }

                console.log("执行",command)
                let clogMsg = child_process.execSync(command).toString();
                let endTime = Date.now();
                let executionTime = endTime - startTime;

                let outmsg =`@${msg.from.username}
${aftips},日志如下
${clogMsg}
本次执行时间，耗时: ${formatMilliseconds(executionTime)}
`;

                await bot.sendMessage(chatId, outmsg);
            }
        }
    }
});

bot.onText(/\/(dp_h5|dp_mc|dp_ad|dp_dash|dp_gp_pay|check_status)/,async (msg, match) => {
    var resp = match[1].trim();
    console.log(msg,match);
    const chatId = msg.chat.id;
    if (inArray(chatId, authChatIds)) {

        await bot.sendMessage(chatId, commandArr[match[1]]['bftips']);

        let aftips = commandArr[match[1]]['aftips'];

        let startTime = Date.now();
        let command = commandArr[match[1]]['cmd'];
        console.log("执行",command)
        let clogMsg = child_process.execSync(command).toString();
        let endTime = Date.now();
        let executionTime = endTime - startTime;

        let outmsg =`@${msg.from.username}
${aftips},日志如下
${clogMsg}
本次执行时间，耗时: ${formatMilliseconds(executionTime)}
`;

        await bot.sendMessage(chatId, outmsg);

    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});

// 定時任務
// 設置每小時執行一次autocheck
const interval = 60 * 60 * 1000; // 60分鐘 * 60秒 * 1000毫秒
setInterval(async () => {
    const chatId = authChatIds[1];
    await ckModule.autocheck(bot, chatId, "pre_check", { from: { username: "system" },});
}, interval); // 每小時執行一次