#! /bin/bash
namespace=$1
etcSets=("etcd1" "etcd2" "etcd3")

if [ ! -d "/data/k8s/etcd" ];then
    mkdir -p /data/k8s/etcd
fi

#检查k8s的命名空间是否存在 ，如果不存在就创建
kubectl get namespace $namespace > /dev/null 2>&1
NAMESPACE_EXISTS=$?

if [ $NAMESPACE_EXISTS -eq 0 ]; then
  echo "检查命名空间[$namespace]已经存在."
  echo ""
else
  kubectl create namespace $namespace
  kubectl create secret generic mydocker-reg-sec \
    --from-file=.dockerconfigjson=/root/.docker/config.json  \
    --type=kubernetes.io/dockerconfigjson -n $namespace
  echo "全名空间[$namespace]创建成功."
  echo "全名空间[$namespace]下docker的Secret创建成功."
  echo ""
fi

#该namespace中创建etcd集群服务
for item in "${etcSets[@]}";do
cat>/data/k8s/etcd/$namespace-${item}-deploy.yaml<<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${item}
  namespace: ${namespace}
  labels:
    name: ${item}
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ${item}
  template:
    metadata:
      labels:
        app: ${item}
    spec:
      restartPolicy: Always
      containers:
      - name: ${item}
        image: quay.io/coreos/etcd:latest
        imagePullPolicy: IfNotPresent
        env:
        - name: host_ip
          valueFrom:
            fieldRef:
              fieldPath: status.podIP
        command: ["/bin/sh","-c"]
        args:
        - /usr/local/bin/etcd
          --name ${item}
          --initial-advertise-peer-urls http://\${host_ip}:2380
          --listen-peer-urls http://\${host_ip}:2380
          --listen-client-urls http://\${host_ip}:2379,http://127.0.0.1:2379
          --advertise-client-urls http://\${host_ip}:2379
          --initial-cluster-token etcd-cluster
          --initial-cluster etcd1=http://etcd1:2380,etcd2=http://etcd2:2380,etcd3=http://etcd3:2380
          --initial-cluster-state new
          --data-dir=/data
---
apiVersion: v1
kind: Service
metadata:
  name: ${item}
  namespace: ${namespace}
spec:
  clusterIP: None
  ports:
  - name: client
    port: 2379
    targetPort: 2379
  - name: message
    port: 2380
    targetPort: 2380
  selector:
    app: ${item}
EOF
echo "执行kubectl apply [kubectl apply -f /data/k8s/etcd/$namespace-${item}-deploy.yaml]"
echo ""
kubectl apply -f /data/k8s/etcd/$namespace-${item}-deploy.yaml
done