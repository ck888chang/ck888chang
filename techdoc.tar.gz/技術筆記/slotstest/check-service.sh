#!/bin/bash
source /etc/profile


checkCMD(){
  CMD=`$1`

}

# check slotstest po
checkPod(){
  CMD=`kubectl get po -n slotstest|awk '{print $1,$3}'|grep -v 'NAME'|grep -v  'Running'|awk '{print $1":"$2}'`
  for line in $CMD
  do
    Svc_Name=`echo $line |awk -F":" '{print $1}' `
    Status=`echo $line |awk -F':' '{print $2}' `
    sendMessage $Svc_Name  $Status "游戏测试环境"
  done

}

checkGame(){
  CMD=`supervisorctl status|awk '{print $1":"$2}'|grep -v 'RUNNING'`
  for line in $CMD
  do
    Svc_Name=`echo $line |awk -F":" '{print $1}' `
    Status=`echo $line |awk -F':' '{print $2}' `
    sendMessage $Svc_Name  $Status "游戏测试环境"
  done
}

#send telegram
sendMessage(){
  Svc_Name=$1
  Svc_Status=$2
  Svc_Kind=$3

  echo "send tg function"
  echo $1 $2 $3
  # https://api.telegram.org/bot<TOKEN>/sendMessage?chat_id=<CHAT_ID>&text=Hello%20World
  ### chat_id=-1002007018976 為遊戲test 後端群
  curl -X POST \
     -H 'Content-Type: application/json' \
     -d '{"chat_id": "-1002007018976", "text":" '"执行时间: ${time} UTC \n环境名称: $Svc_Kind \n服务名称: $Svc_Name \n状态异常: $Svc_Status \n详细日志:见如下日志文件. "'", "disable_notification": true}' \
     https://api.telegram.org/bot6665489299:AAHdDoxL-DkD3i46kV75TllSmG2R0jcyUZk/sendMessage
  # 生成错误文件路径
  logPath=`find /data/service_exec -name fatal.log | grep  $Svc_Name`
  # 发送文件
  curl -s -X POST "https://api.telegram.org/bot6665489299:AAHdDoxL-DkD3i46kV75TllSmG2R0jcyUZk/sendDocument" \
        -F "chat_id=-1002007018976" \
        -F "document=@${logPath}"

  filePath=`find /data/logs/slots_service/ -name $Svc_Name-console.log`
    curl -s -X POST "https://api.telegram.org/bot6665489299:AAHdDoxL-DkD3i46kV75TllSmG2R0jcyUZk/sendDocument" \
         -F "chat_id=-1002007018976" \
         -F "document=@${filePath}"
}


checkPod
checkGame