// 程式所在位置
//root@slots-test-main:/home/jnodes/slots_deploy_tg# cat test_slots_deploy_tg.js

// 引入所需的 Node.js 模塊和第三方庫
const TelegramBot = require('node-telegram-bot-api');
const util = require('util');
const moment = require("moment");
const child_process = require('child_process');
const yaml = require('js-yaml');
const fs = require('fs');
const { Worker } = require('worker_threads');

// Telegram 機器人的令牌
const token = '6412559730:AAGp63hSmQKpNJ8FRqYn7_TA3dxcPKP2x0A';

// 授權的聊天 ID，只有這些聊天 ID 可以執行特定操作
const authChatIds = [6553682453,-4074716871];

// 未授權信息提示
const unAthInfo = "你的信息已记录，请联系管理员授权!";

// 定義一個異步等待函數
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// 格式化毫秒數為分鐘和秒的字符串表示
function formatMilliseconds(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(2);
    return `${minutes} 分 ${seconds} 秒`;
}

// 創建 Telegram 機器人實例
const bot = new TelegramBot(token, {
    polling: true
});

// 定義命令對應的執行腳本和提示信息
let commandArr = {};

let commandArr = {};

const serviceConfigs = [
    { key: 'GateServer', name: 'GateServer' },
    { key: 'HallServer', name: 'HallServer' },
    { key: 'st_ad_sv', name: 'slots-server-admin', port: 6007, token: 'f2b2e1232868cbfe9980b6dfd87e23ce2dc101' },
    { key: 'st_ad_wb', name: 'slot-web-admin', port: 6006, token: '10me12868cbfe9980b6dfd87e23ce2dc1' },
    { key: 'st_mc_sv', name: 'slots-server-merchat', port: 6004, token: 'f2b2e12868cbfe9980b6dfd87e23ce2dc101' },
    { key: 'st_mc_wb', name: 'slot-web-merchant', port: 6005, token: 'fbme12868cbfe9980b62dfd87e23ce2dc1' },
    { key: 'st_mc_api', name: 'solts-api-merchant', port: 6002, token: 'f2be12868cbfe9980b6dfd87e23ce2dc1' },
    { key: 'st_of_wb', name: 'slots-web-official', port: 6003, token: 'fbme12868cbfe9980b6dfd87e23ce2dc1' },
    { key: 'test_status', name: 'test_status', cmd: 'kubectl get pods -n slotstest' },
    { key: 'test1_status', name: 'test1_status', cmd: 'kubectl get pods -n slotstest1' },
];

for (const config of serviceConfigs) {
    const { key, name, port, token, cmd } = config;

    commandArr[key] = {
        bftips: name ? `收到！正在执行发布${name} test分支到Test环境，请稍等1-8分钟...` : '',
        cmd: cmd || (name ? `curl -s --location 'http://172.31.14.232:${port}/deploy'  \
            --header 'token: ${token}' \
            --header 'Content-Type: application/x-www-form-urlencoded'  \
            --data-urlencode 'branch=test'` : ''),
        aftips: name ? `Hi! 发布${name} test分支到Test环境完成` : '',
    };
}

// 讀取 YAML 文件中的數據
const yamlData = fs.readFileSync('consts.yaml', 'utf8');
const parsedData = yaml.load(yamlData);

// 從 YAML 數據中提取各類服務的名稱並生成命令對象
const SpecialGameServers = parsedData["SpecialGameServers"];
const GameServers = parsedData["GameServers"];
const MiniGameServers = parsedData["MiniGameServers"];
const MainServers =  parsedData["MainServers"];

const serverTypes = [MainServers, GameServers, MiniGameServers, SpecialGameServers];

let slotsAllGameServers = [];
let serverNameStr = '';

serverTypes.forEach(serverType => {
    serverType.forEach(gserver => {
        serverNameStr += gserver + ',';
        commandArr[gserver] = {};
        slotsAllGameServers.push(gserver);
    });
});

serverNameStr = serverNameStr.slice(0, -1);  // 移除最後的逗號


// 定義環境和分支的名稱
const envName='测试环境';
const branchName='test';

// 創建幫助信息
const helpMsg = `Only:
\/st_ad_sv       [在${envName}发布Server-Admin项目于${branchName}分支]

\/st_ad_wb       [在${envName}发布Slots-Web-Admin项目于${branchName}分支]

\/st_mc_sv       [在${envName}发布Server-Merchant项目于${branchName}分支]

\/st_mc_wb       [在${envName}发布Slots-Web-Merchant项目于${branchName}分支]

\/st_mc_api      [在${envName}发布Server-merchant-api项目于${branchName}分支]

\/st_of_wb       [在${envName}发布Slots-Web-Official项目于${branchName}分支]

\/gd deploy 游戏服务名 [在${envName}发布Slots-Games-Go-API项目于${branchName}分支,游戏服务名有:${serverNameStr};示例 \/gd deploy GateServer]

\/gAll  [在${envName}发布Slots-Games-Go-API项目于${branchName}分支,所有游戏服务]

\/test_status   [检查${envName}k8s状态]
\/test1_status   [检查${envName}k8s状态]
`

// 監聽 /help 命令，根據聊天 ID 判斷是否為授權用戶
bot.onText(/\/help/, async msg => {
    console.log(msg);
    const chatId = msg.chat.id;

    if (authChatIds.includes(chatId)) {
        // 确认授权的群，发送help提示
        await bot.sendMessage(chatId, helpMsg);
    } else {
        //非授权提示
        await bot.sendMessage(chatId, unAthInfo);
    }
});

// 定義一個通用的提示信息對象
const commonTips = {
    'gd-deploy':{
        'bftips':`收到！正在执行发布Slots-Games-Go-API 的 %s 的 ${branchName}分支到${envName}，请稍等1-6分钟...`,
        'aftips':`Hi! 发布Slots-Games-Go-API的%s于分支[${branchName}]${envName}完成`,
    },
    'gd-deploy-all':{
        'bftips':`收到！正在执行发布Slots-Games-Go-API 的所有服务的${branchName}分支到${envName}，请稍等10-%s分钟...`,
        'aftips':`Hi! 发布Slots-Games-Go-API的所有服务于分支[${branchName}]${envName}完成`,
    }
}

// 定義通用的命令對象
const commondCommandS = {
    'gd-deploy':{
         'cmd':` curl -s --location 'http://172.31.14.232:6008/deploy' \
          --header 'token: f2be12868cbfe9980b6dfd87e23ce2dc1' \
          --header 'Content-Type: application/x-www-form-urlencoded' \
          --data-urlencode 'branch=${branchName}' \
          --data-urlencode 'gameCode=%s'`
    }
 }

// 定義遊戲服務佈建的函數
async function gameServerDeploy(chatId,username,gameServer,typeAll=false){
    let cTime = moment();
    if(!typeAll){
        if(commandArr[gameServer]['bftips']){
            await bot.sendMessage(chatId, commandArr[gameServer]['bftips']);
        }else{
            await bot.sendMessage(chatId, util.format(commonTips[`gd-deploy`]['bftips'], gameServer));
        }
    }


    let aftips = '';
    if(commandArr[gameServer]['aftips']){
        aftips = commandArr[gameServer]['aftips'];
    }else{
        aftips = util.format(commonTips[`gd-deploy`]['aftips'], gameServer);
    }

    let startTime = Date.now();
    let command = '';
    if(commandArr[gameServer]['cmd']){
        command = commandArr[gameServer]['cmd'];
    }else{
        command =  util.format(commondCommandS[`gd-deploy`]['cmd'], gameServer)
    }
    console.log("执行",command)
    let clogMsg = child_process.execSync(command).toString().trim();
    let endTime = Date.now();
    let executionTime = endTime - startTime;
    let sendFileName = `./deploy-logs/${username}-${gameServer}-deploy-${cTime.format('YYYY-MM-DD-HH-mm-ss')}.txt`;
    fs.writeFileSync(sendFileName, clogMsg);
    let outmsg = '';
    //if(!typeAll){
        outmsg =`@${username}
${aftips},日志文件如下`;
        await bot.sendMessage(chatId, outmsg);
    //}

    if(clogMsg.endsWith('发布成功')){
        await bot.sendDocument(chatId, sendFileName, {
            contentType: 'text/plain',
        });
        await bot.sendMessage(chatId, '<strong>发布成功</strong>', {parse_mode: 'HTML'});
    }else{
        await bot.sendDocument(chatId, sendFileName, {
            contentType: 'text/plain',
        });
        await bot.sendMessage(chatId, '<strong><code>发布失败</code></strong>', {parse_mode: 'HTML'});
    }
    //if(!typeAll){
        outmsg =`本次执行时间，耗时: ${formatMilliseconds(executionTime)}`;
        await bot.sendMessage(chatId, outmsg);
    //}

}

// 監聽 /gd 命令，執行遊戲服務佈建
bot.onText(/\/gd(.+)/, async (msg, match) => {
    var resp = match[1].trim();
    console.log(msg,match);
    const chatId = msg.chat.id;
    if (authChatIds.includes(chatId)) {
        let paramsArr =  resp.split(" ").filter(e=>e.trim());
        if(paramsArr.length != 2){
            paramsArr =  resp.split("_").filter(e=>e.trim());
        }
        if(paramsArr.length == 2){
            if(paramsArr[0] == "deploy"){
                if(!commandArr[paramsArr[1]]){
                    await bot.sendMessage(chatId, ' \/gd deploy 命令的服务名错误!');
                    return;
                }
                let gameServer = paramsArr[1];
                await gameServerDeploy(chatId,msg.from.username,gameServer);
            }
        }
    }
});

// 監聽 /gAll 命令，執行所有遊戲服務佈建
bot.onText(/\/(gAll)/, async (msg, match) => {
    const resp = match[1].trim();
    console.log(msg, match);
    const chatId = msg.chat.id;

    if (authChatIds.includes(chatId)) {
        const startTime = Date.now();
        await bot.sendMessage(chatId, util.format(commonTips['gd-deploy-all']['bftips'], slotsAllGameServers.length));
        const typeAll = true;

        const createWorkers = (startIndex, endIndex) => {
            const workers = [];
            for (let i = startIndex; i < endIndex; i++) {
                const gServerName = slotsAllGameServers[i];
                workers.push(new Worker('./test_slots_deploy_worker.js', { workerData: { chatId, username: msg.from.username, gameServer: gServerName } }));
            }
            return workers;
        };

        const numWorkers = 10;
        const workersMap = [];

        for (let i = 0; i < slotsAllGameServers.length; i += numWorkers) {
            const endIndex = Math.min(i + numWorkers, slotsAllGameServers.length);
            const workers = createWorkers(i, endIndex);

            workers.forEach(worker => {
                worker.on('message', message => {
                    console.log(`工作线程1 发送消息: ${message}`);
                });

                workersMap.push(new Promise(resolve => worker.on('exit', resolve)));
            });

            await Promise.all(workersMap);
        }

        await bot.sendMessage(chatId, commonTips['gd-deploy-all']['aftips']);
        const endTime = Date.now();
        const executionTime = endTime - startTime;
        const outmsg = `本次执行Slots-Games-Go-API项目所有服务发布时间，耗时: ${formatMilliseconds(executionTime)}`;
        await bot.sendMessage(chatId, outmsg);
    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});


// 監聽其他佈建命令，執行相應的佈建操作
bot.onText(/\/(st_ad_sv|st_ad_wb|st_mc_sv|st_mc_wb|st_mc_api|st_of_wb|test_status|test1_status)/,async (msg, match) => {
    var resp = match[1].trim();
    console.log(msg,match);
    const chatId = msg.chat.id;
    if (authChatIds.includes(chatId)) {
        await bot.sendMessage(chatId, commandArr[match[1]]['bftips']);
        let startTime = Date.now();
        let command = commandArr[match[1]]['cmd'];
        let aftips = commandArr[match[1]]['aftips'];
        console.log("执行",command)
        let clogMsg = child_process.execSync(command).toString();
        let endTime = Date.now();
        let executionTime = endTime - startTime;

        let outmsg =`@${msg.from.username}
${aftips},日志如下
${clogMsg}
本次执行时间，耗时: ${formatMilliseconds(executionTime)}
`;
        await bot.sendMessage(chatId, outmsg);

    } else {
        await bot.sendMessage(chatId, unAthInfo);
    }
});