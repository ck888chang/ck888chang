#!/bin/bash
### 2024年1月23日，由CK編寫，如果有問題可以問AI
# 配置 alertmanager 資料夾
AlertM_DIR="/data/alertmanager"
if [ ! -d "$AlertM_DIR" ]; then
    mkdir -p "$AlertM_DIR"
    chown 65534:65534 "$AlertM_DIR"
fi

# 配置 alertmanager yml 檔案
AlertM_FILE="$AlertM_DIR/alertmanager.yml"
if [ ! -f "$AlertM_FILE" ]; then
    cat > "$AlertM_FILE" << EOF
route:
  group_by: ['alertname']
  group_wait: 30s
  group_interval: 30s
  repeat_interval: 5m
  receiver: 'web.hook'
receivers:
  - name: 'web.hook'
    webhook_configs:
#      - url: 'http://10.30.5.205:8082/'
      - url: 'http://172.31.13.90:8082/'
inhibit_rules:
  - source_match:
      severity: 'critical'
    target_match:
      severity: 'warning'
    equal: ['alertname', 'dev', 'instance']
EOF
fi

# 配置 alertmanager 參數檔案
AlertM_FILE="$AlertM_DIR/alertmanager.yml"
if [ -f "$AlertM_FILE" ]; then
    chown 65534:65534 "$AlertM_FILE"
fi

# 配置 alertmanager-bot 資料夾
AlertM_bot_DIR="/data/alertmanager-bot"
if [ ! -d "$AlertM_bot_DIR" ]; then
    mkdir -p "$AlertM_bot_DIR"
    chown 0:0 "$AlertM_bot_DIR"
fi

#產出docker-compose文檔
DC_FILE="/data/alertmanager/docker-compose.yml"
if [ ! -f "$DC_FILE" ]; then
    cat > "$DC_FILE" << EOF
version: '3'

services:
  alertmanager:
    image: prom/alertmanager
    container_name: alertmanager
    restart: always
    ports:
      - "9093:9093"
    volumes:
      - /data/alertmanager:/etc/alertmanager

  alertmanager-bot:
    image: metalmatze/alertmanager-bot:0.4.3
    container_name: alertmanager-bot
    restart: always
    environment:
      - ALERTMANAGER_URL=http://172.31.13.90:9093
#      - ALERTMANAGER_URL=http://10.30.5.205:9093
      - STORE=bolt
      - TELEGRAM_ADMIN=6934305124
#      - TELEGRAM_TOKEN=bot6840034038:AAGY75FhkkEZXpXz309S5OM5_rkVcSvgYvI # token最前面不用加bot三個字
#      - TELEGRAM_TOKEN=6840034038:AAGY75FhkkEZXpXz309S5OM5_rkVcSvgYvI    # CK測試用
      - TELEGRAM_TOKEN=6795355185:AAEITI3Oc4BhDkX60xGXVIM0xhymLBdQHrU     # 運維用
    ports:
      - "8082:8080"
EOF
fi

if [ -f "$DC_FILE" ]; then
    cd "$AlertM_DIR"
    docker compose up -d
fi

cat > "$AlertM_DIR/deletealertM.sh" << EOF
#!/bin/bash
### 刪除alertmanager alertmanager-bot，非確定者請勿執行
cd "$AlertM_DIR"
docker compose down
cd /data/
rm -rf alertmanager
rm -rf alertmanager-bot
EOF
