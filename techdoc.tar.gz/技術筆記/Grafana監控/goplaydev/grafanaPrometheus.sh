#!/bin/bash
### 2024年1月23日，由CK編寫，如果有問題可以問AI
### 1月24日繼續編修
mainprocess() {
    # 檢查 Docker 是否已安裝
    if ! command -v docker &> /dev/null; then
        echo "Docker is not installed. Please install Docker and run the script again."
        exit 1
    fi

    # 檢查 Docker 容器是否已存在
    check_container_exists() {
        local container_name="$1"
        if docker ps --format '{{.Names}}' | grep -q "$container_name"; then
            #echo "Container '$container_name' already exists. Exiting script."
            echo -e "\033[31m容器 '$container_name' 已經存在，不允許安裝，離開腳本.\033[0m"
            return 0  # 表示容器已存在
        fi
        return 1  # 表示容器不存在
    }

    # 定義容器名稱陣列
    containers=("grafana" "prometheus" "node" "alertmanager" "alertmanager-bot")
    #containers=("GGGG") ## 測試用

    # flag 變數，用於標記是否有容器已存在
    container_exists=false

    # 使用迴圈進行檢查 xxxxxx  容器是否已存在
    for container in "${containers[@]}"; do
        if check_container_exists "$container"; then
            container_exists=true
        fi
    done

    # 檢查是否有容器已存在
    if $container_exists; then
        echo "Exiting script. At least one container already exists."
        exit 0
    fi

    # 取得本機 IP 地址 #需要有彈性對於不同os要有不同抓ip的方法？
    #CURRENT_IP=$(ip addr show dev ens5 | awk '/inet / {print $2}' | cut -d'/' -f1)
    CURRENT_IP=$(ip addr show ens192 | grep -oP 'inet \K[0-9.]+')
    echo -e "\033[32mCurrent IP address is: $CURRENT_IP"
    echo "目前ip 請確認是否正確: $CURRENT_IP"

    # 提示用戶確認是否繼續執行
    read -p "Do you want to continue? (yes/no): " answer
    if [ "$answer" != "yes" ]; then
        echo "Exiting script."
        exit 0
    else
      ### 呼叫下一步驟程序
      secprocess
    fi
}

secprocess(){
  # 創建 Prometheus 目錄
  base_DIR="/data/monitor"
  prome_DIR="$base_DIR/prometheus"
  AlertM_DIR="$base_DIR/alertmanager"
  #AlertM_FILE="$AlertM_DIR/alertmanager.yml"
  AlertM_bot_DIR="$base_DIR/alertmanager-bot"
  if [ ! -d "$base_DIR" ]; then
      mkdir -p "$base_DIR"/{prometheus/rules,alertmanager,alertmanager-bot}
      echo "創建 Prometheus 目錄"
  fi

# 配置 alertmanager yml 檔案
AlertM_FILE="$AlertM_DIR/alertmanager.yml"
if [ ! -f "$AlertM_FILE" ]; then
    cat > "$AlertM_FILE" << EOF
route:
  group_by: ['alertname']
  group_wait: 30s
  group_interval: 30s
  repeat_interval: 5m
  receiver: 'web.hook'
receivers:
  - name: 'web.hook'
    webhook_configs:
      - url: 'http://$CURRENT_IP:8082/'
inhibit_rules:
  - source_match:
      severity: 'critical'
    target_match:
      severity: 'warning'
    equal: ['alertname', 'dev', 'instance']
EOF
  echo "配置 alertmanager yml 檔案"
else
  echo "配置 alertmanager yml 檔案時已存在，不變更"
fi


# 配置 prometheus.yml 檔案

Prome_FILE="$prome_DIR/prometheus.yml"
if [ ! -f "$Prome_FILE" ]; then
    cat > "$Prome_FILE" << EOF
##cat prometheus.yml
# my global config
global:
  scrape_interval: 15s # Set the scrape interval to every 15 seconds. Default is every 1 minute.
  evaluation_interval: 15s # Evaluate rules every 15 seconds. The default is every 1 minute.
  scrape_timeout: 15s

alerting:
  alertmanagers:
    - static_configs:
        - targets:
            - $CURRENT_IP:9093

rule_files:
  - /etc/prometheus/rules/*.rules

scrape_configs:
  - job_name: "開發測試場"
    metrics_path: /metrics
    scheme: http
    static_configs:
      - targets:
        - "$CURRENT_IP:5100"
        labels:
          instance: LOCAL_HOST
      - targets:
        - "172.31.13.90:5100"
        labels:
          instance: goplay-test-main
      - targets:
        - "172.31.0.34:5100"
        labels:
          instance: goplay-test-node
      - targets:
        - "172.31.14.232:5100"
        labels:
          instance: slots-test-main
      - targets:
        - "172.31.8.166:5100"
        labels:
          instance: slots-test-node
  - job_name: "liulang-web-host"
    metrics_path: /metrics
    scheme: http
    static_configs:
      - targets:
        - "154.39.192.42:9182"
        labels:
          instance: liuliang-web-host
  - job_name: "預發場"
    metrics_path: /metrics
    scheme: http
    static_configs:
      - targets:
        - "172.31.20.199:5100"
        labels:
          instance: prereleasemain
      - targets:
        - "172.31.31.246:5100"
        labels:
          instance: prereleasenode
      - targets:
        - "172.31.23.60:5100"
        labels:
          instance: prereleasedb
      - targets:
        - "172.31.10.24:5100"
        labels:
          instance: prereleaseslotsnode1
      - targets:
        - "172.31.12.40:5100"
        labels:
          instance: prereleaseslotsnode2
  - job_name: "slot-test-rabbitmq"
    metrics_path: /metrics
    scheme: http
    static_configs:
      - targets:
        - "172.31.14.232:9419"
        labels:
          instance: slotst-test-mq
EOF
  echo "配置 prometheus.yml 檔案"
else
  echo "配置 prometheus.yml 檔案時已存在，不變更"
fi


# 配置 web.yml 檔案 ，需注意檔案內容不能有$，如果有$需要在之前加上\，使其成為\$
Web_FILE="$prome_DIR/web.yml"
if [ ! -f "$Web_FILE" ]; then
    cat > "$Web_FILE" << EOF
basic_auth_users:
  admin: \$2b\$12\$0W9xD.4t9uHKGvIdg9ZJTeJXzUTONVVbKQ3DmIC6.NjE62WDrxhi6
EOF
fi

# 配置 hostStats-Alert.rules 檔案，需注意檔案內容不能有$，如果有$需要在之前加上\，使其成為\$
hoststats_FILE="$prome_DIR/rules/hoststats-alert.rules"
if [ ! -f "$hoststats_FILE" ]; then
    cat > "$hoststats_FILE" << EOF
groups:
- name: hostStatsAlert
  rules:
  - alert: hostDiskUsageAlert
    expr: round(100-(node_filesystem_free_bytes{fstype=~"ext4|xfs"}/node_filesystem_size_bytes {fstype=~"ext4|xfs"}*100)) > 80
    for: 1m
    labels:
      severity: page
    annotations:
      summary: "Instance {{ \$labels.instance }} Disk usgae high"
      description: "{{ \$labels.instance }} MEM usage above 80% (current value: {{ \$value }}%)"
  - alert: hostMemUsageAlert
    expr: round((node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes)/node_memory_MemTotal_bytes{job="test-dev-host"}  * 100) > 80
    for: 1m
    labels:
      severity: page
    annotations:
      summary: "Instance {{ \$labels.instance }} MEM usgae high"
      description: "{{ \$labels.instance }} MEM usage above 80% (current value: {{ \$value }})%"
  - alert: PrometheusTargetMissing
    expr: up == 0
    for: 0m
    labels:
      severity: critical
    annotations:
      summary: "Prometheus target missing (instance {{ \$labels.instance }})"
      description: "A Prometheus target has disappeared. An exporter might be crashed.\n  VALUE = {{ \$value }}\n  LABELS = {{ \$labels }}"
  - alert: HostOutOfInodes
    expr: 100- (node_filesystem_files_free{mountpoint="/"} / node_filesystem_files{mountpoint="/"})  * 100  > 80
    for: 2m
    labels:
      severity: warning
    annotations:
      summary: Host out of inodes (instance {{ \$labels.instance }})
      description: "Disk is almost running out of available inodes  above 80%  VALUE = {{ \$value }}  LABELS = {{ \$labels }}"
  - alert: HosthighCPULoad
    expr:  sum by (instance) (avg by (mode,instance) (rate(node_cpu_seconds_total{mode !="idle"}[5m]))) * 100 > 80
    for: 2m
    labels:
      severity: warning
    annotations:
      summary: Host high CPU load (instance {{ \$labels.instance }})
      description: "CPU load is > 80%\n  VALUE = {{ \$value }}%  LABELS = {{ \$labels }}"
EOF
  echo "配置 web.yml 檔案"
else
  echo "配置 web.yml 檔案時已存在，不變更"
fi

# 配置 rabbit-mq-alert.rules 檔案
rabbit_mq_FILE="$prome_DIR/rules/rabbit-mq-alert.rules"
if [ ! -f "$rabbit_mq_FILE" ]; then
    cat > "$rabbit_mq_FILE" << EOF
groups:
#when connections over 500 alert
- name: rabbitmq_connections
  rules:
  - alert: RabbitMQTooManyConnections
    expr: rabbitmq_connections > 500
    for: 5m
    labels:
      severity: critical
    annotations:
      summary: "RabbitMQ has too many connections"
      description: "The RabbitMQ server has {{ \$value }} connections, which is above the threshold of 500 connections."

- name: RabbitMQ-queue-message over 1000
  rules:
  - alert: RabbitMQTomManyMessages
    expr: max(rabbitmq_queue_messages_published_total) > 1000
    labels:
      status: High
    annotations:
      description: "Instance: {{ \$labels.instance }} the rabbitmq_queue_messages over 1000  ! ! !"
      value: '{{ \$value }} '
      summary:  "RabbitMQ too many messages!"
EOF
  echo "配置 rabbit-mq-alert.rules 檔案"
else
  echo "配置 rabbit-mq-alert.rules 時檔案已存在，不變更"
fi

# 配置 alertmanager-bot 樣版檔案
#todo:尚待修改板版格式
AlertM_bot_FILE="$AlertM_bot_DIR/default.tmpl"
if [ ! -f "$AlertM_bot_FILE" ]; then
    cat > "$AlertM_bot_FILE" << EOF
{{ define "telegram.default" }}
{{ range .Alerts }}
{{ if eq .Status "firing"}}🔥 <b>{{ .Status | toUpper }}</b> 🔥{{ else }}<b>{{ .Status | toUpper }}</b>{{ end }}
<b>{{ .Labels.alertname }}</b>
{{ if .Annotations.message }}
{{ .Annotations.message }}
{{ end }}
{{ if .Annotations.summary }}
{{ .Annotations.summary }}
{{ end }}
{{ if .Annotations.description }}
{{ .Annotations.description }}
{{ end }}
<b>Duration:</b> {{ duration .StartsAt .EndsAt }}{{ if ne .Status "firing"}}
<b>Ended:</b> {{ .EndsAt | since }}{{ end }}
{{ end }}
{{ end }}
EOF
  echo "配置 alertmanager-bot 樣版檔案"
else
  echo "配置 alertmanager-bot 樣版檔案時已存在，不變更"
fi

  if [ -d "$base_DIR" ]; then
      chown -R 65534:65534 "$prome_DIR"
      chown -R 65534:65534 "$AlertM_DIR"
      chown 0:0 "$AlertM_bot_DIR"
      echo -e "授權 Prometheus 相關目錄用戶權限 \033[0m"
  else
      echo -e "授權 Prometheus 相關目錄,目錄不存在 \033[0m"
  fi

### 呼叫下一步驟程序
dockerprocess
}


dockerprocess(){
# 配置 Docker-compose.yaml 樣版檔案
dc_FILE="$base_DIR/docker-compose.yaml"
if [ ! -f "$dc_FILE" ]; then
    cat > "$dc_FILE" << EOF
version: '3'

services:
  node-exporter:
    image: prom/node-exporter:latest
    container_name: node-exporter
    ports:
      - "5100:9100"
    restart: always
    networks:
      - MonitorNet

  prometheus:
    image: prom/prometheus:latest
    container_name: prometheus
    ports:
      - "9090:9090"
    restart: always
    volumes:
      - $base_DIR/prometheus/web.yml:/etc/prometheus/web.yml
      - $base_DIR/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml
      - $base_DIR/prometheus/rules:/etc/prometheus/rules
    networks:
      - MonitorNet

  grafana:
    image: grafana/grafana:latest
    container_name: grafana
    ports:
      - "3000:3000"
    restart: always
    networks:
      - MonitorNet

  alertmanager:
    image: prom/alertmanager
    container_name: alertmanager
    restart: always
    ports:
      - "9093:9093"
    volumes:
      - $base_DIR/alertmanager:/etc/alertmanager
    networks:
      - MonitorNet

  alertmanager-bot:
    image: metalmatze/alertmanager-bot:latest
    container_name: alertmanager-bot
    restart: always
    environment:
#      - ALERTMANAGER_URL=http://172.31.13.90:9093
      - ALERTMANAGER_URL=http://$CURRENT_IP:9093
      - STORE=bolt
      - TELEGRAM_ADMIN=6934305124
      - TELEGRAM_TOKEN=6840034038:AAGY75FhkkEZXpXz309S5OM5_rkVcSvgYvI    # CK測試用
#      - TELEGRAM_TOKEN=6795355185:AAEITI3Oc4BhDkX60xGXVIM0xhymLBdQHrU     # 運維用
    ports:
      - "8082:8080"
    volumes:
      - $base_DIR/alertmanager-bot/default.tmpl:/templates/default.tmpl
    networks:
      - MonitorNet
networks:
  MonitorNet:
    driver: bridge
EOF
  echo "update配置 Docker-compose.yaml 樣版檔案"
else
  echo "配置 Docker-compose.yaml 樣版檔案時已存在，不變更"
fi


    if [ -f "$dc_FILE" ]; then
        cd "$base_DIR"
        output=$(docker compose up -d)

        # 检查命令的返回码
        if [ $? -eq 0 ]; then
            echo "docker compose up -d 上線成功."
            ### 呼叫下一步驟程序
            loginmessage
            delfun
        else
            echo -e "\033[31m docker compose up -d 失敗請檢查相關錯誤訊息\033[0m"
            echo "$output"  # 输出命令的标准输出和错误输出
            # 在此添加处理失败的代码
        fi
    fi
}

loginmessage(){
    promeIP=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' prometheus)
    echo "Grafana 登入頁  http://$CURRENT_IP:3000"
    echo "Prometheus 登入頁  http://$CURRENT_IP:9090"
    echo "alertmanager 登入頁  http://$CURRENT_IP:9093"
    echo "Node-exporter metrics  http://$CURRENT_IP:5100/metrics"
    echo "填加Prometheus資料來源$promeIP，並使用儀表版號碼16098套用"
}

delfun(){
cat > "$base_DIR/deleteGPNAA.sh" << EOF
#!/bin/bash
#deleteGPNAA.sh刪除Grafana Prometheus Node-exporter Alertmanager Alertmanager-bot，非確定者請勿執行
cd "$base_DIR"
docker compose down
cd $base_DIR/..
rm -rf $base_DIR
EOF
}


#1.检查系统
if [ "$EUID" -ne 0 ]; then
    echo -e  "\033[31m 必须是root用户才能执行此脚本 \033[0m" 2>&1
    exit 1
else
    ### 呼叫下一步驟程序
    mainprocess
    cd "$base_DIR"
fi